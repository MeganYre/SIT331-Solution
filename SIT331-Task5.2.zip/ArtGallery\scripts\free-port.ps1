# Stops only ArtGallery API hosts on port 5288 (does NOT kill "dotnet run" itself).
$port = 5288

Get-Process -Name ArtGallery -ErrorAction SilentlyContinue |
    Stop-Process -Force -ErrorAction SilentlyContinue

Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue |
    ForEach-Object {
        $proc = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue
        if ($null -eq $proc) { return }
        # Only stop the compiled API host, never arbitrary dotnet builds.
        if ($proc.ProcessName -eq 'ArtGallery') {
            Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue
        }
    }

Start-Sleep -Milliseconds 300
