namespace ArtGallery.Auth;

public static class GalleryRoles
{
    public const string Visitor = "Visitor";
    public const string Curator = "Curator";
    public const string Admin = "Admin";

    public static readonly string[] All = [Visitor, Curator, Admin];
}
