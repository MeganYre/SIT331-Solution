using MongoDB.Bson.Serialization.Attributes;

namespace ArtGallery.Artifacts;

/// <summary>
/// Artifacts bounded context: individual works of Aboriginal art in the collection.
/// </summary>
[BsonIgnoreExtraElements]
public class Artifact
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public string? Medium { get; set; }
    public int? YearCreated { get; set; }
    public string? Description { get; set; }
    public string? ArtType { get; set; }
    public int ArtistId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime ModifiedAt { get; set; }

    [BsonIgnore]
    public Artists.Artist? Artist { get; set; }

    [BsonIgnore]
    public ICollection<Exhibitions.ExhibitionArtifact> ExhibitionArtifacts { get; set; } =
        new List<Exhibitions.ExhibitionArtifact>();
}
