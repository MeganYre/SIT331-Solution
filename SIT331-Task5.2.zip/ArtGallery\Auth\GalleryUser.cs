using MongoDB.Bson.Serialization.Attributes;

namespace ArtGallery.Auth;

/// <summary>
/// Users bounded context: gallery accounts with role-based access.
/// </summary>
[BsonIgnoreExtraElements]
public class GalleryUser
{
    public int Id { get; set; }
    public string Email { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string Role { get; set; } = GalleryRoles.Visitor;
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }
}
