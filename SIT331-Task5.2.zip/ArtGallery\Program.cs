using System.Reflection;
using System.Text;
using ArtGallery.Artifacts;
using ArtGallery.Artists;
using ArtGallery.Auth;
using ArtGallery.Exhibitions;
using ArtGallery.Infrastructure;
using ArtGallery.Persistence;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi;

var builder = WebApplication.CreateBuilder(args);

builder.WebHost.UseUrls("http://127.0.0.1:5288");

builder.Services.Configure<MongoDbSettings>(builder.Configuration.GetSection("MongoDb"));
builder.Services.Configure<JwtSettings>(builder.Configuration.GetSection("Jwt"));
builder.Services.AddSingleton<ArtGalleryDatabase>();
builder.Services.AddHealthChecks().AddCheck<MongoHealthCheck>("mongodb");

builder.Services.AddSingleton<PasswordService>();
builder.Services.AddSingleton<JwtTokenService>();
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<IArtistRepository, ArtistRepository>();
builder.Services.AddScoped<IArtifactRepository, ArtifactRepository>();
builder.Services.AddScoped<IExhibitionRepository, ExhibitionRepository>();

var jwt = builder.Configuration.GetSection("Jwt").Get<JwtSettings>()
    ?? throw new InvalidOperationException("Jwt configuration is required.");

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = jwt.Issuer,
            ValidAudience = jwt.Audience,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.Key)),
            ClockSkew = TimeSpan.FromMinutes(1)
        };
        options.Events = new JwtBearerEvents
        {
            OnChallenge = async context =>
            {
                context.HandleResponse();
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                context.Response.ContentType = "application/json";
                await context.Response.WriteAsJsonAsync(new
                {
                    error = "Missing or invalid JWT. In Swagger: POST /api/auth/login, copy the token, click Authorize, paste the token only (do not type Bearer — Swagger adds it)."
                });
            }
        };
    });

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("CanRead", policy =>
        policy.RequireRole(GalleryRoles.Visitor, GalleryRoles.Curator, GalleryRoles.Admin));
    options.AddPolicy("CanWrite", policy =>
        policy.RequireRole(GalleryRoles.Curator, GalleryRoles.Admin));
});

builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.ReferenceHandler =
            System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles;
    });

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Art Gallery API",
        Version = "v1",
        Description = """
            Australian Aboriginal art gallery backend (SIT331 Task 5.2).

            JWT authentication with Visitor, Curator, and Admin roles.
            MongoDB document store, xUnit tests, XML documentation, and web UI.
            """
    });

    var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    if (File.Exists(xmlPath))
        options.IncludeXmlComments(xmlPath);

    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = """
            Paste ONLY the token from POST /api/auth/login (the long string).
            Do NOT type the word Bearer — Swagger adds it automatically.
            """,
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT"
    });
    options.AddSecurityRequirement(document => new OpenApiSecurityRequirement
    {
        [new OpenApiSecuritySchemeReference("Bearer", document)] = []
    });
});

var app = builder.Build();

try
{
    var db = app.Services.GetRequiredService<ArtGalleryDatabase>();
    await MongoDbSeeder.SeedAsync(db);
}
catch (Exception ex)
{
    var mongo = app.Services.GetRequiredService<IOptions<MongoDbSettings>>().Value;
    Console.Error.WriteLine("MongoDB error — ensure MongoDB is running:");
    Console.Error.WriteLine($"  Connection: {mongo.ConnectionString}");
    Console.Error.WriteLine($"  Database:   {mongo.DatabaseName}");
    Console.Error.WriteLine($"  Message:    {ex.Message}");
    return;
}

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(options =>
    {
        options.SwaggerEndpoint("/swagger/v1/swagger.json", "Art Gallery API v1");
        options.RoutePrefix = "swagger";
        options.DocExpansion(Swashbuckle.AspNetCore.SwaggerUI.DocExpansion.List);
        options.DisplayRequestDuration();
    });
}

if (!app.Environment.IsDevelopment())
    app.UseHttpsRedirection();

app.UseDefaultFiles();
app.UseStaticFiles();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.MapHealthChecks("/health");

app.Lifetime.ApplicationStarted.Register(() =>
{
    var mongo = app.Services.GetRequiredService<IOptions<MongoDbSettings>>().Value;

    foreach (var url in app.Urls)
    {
        Console.WriteLine();
        Console.WriteLine("============================================");
        Console.WriteLine("  Art Gallery API is running");
        Console.WriteLine($"  Database: MongoDB ({mongo.DatabaseName})");
        Console.WriteLine($"  Swagger:  {url}/swagger");
        Console.WriteLine($"  Web UI:   {url}/index.html");
        Console.WriteLine($"  Health:   {url}/health");
        Console.WriteLine("  Demo logins:");
        Console.WriteLine("    curator@gallery.au / Curator123!");
        Console.WriteLine("    visitor@gallery.au / Visitor123!");
        Console.WriteLine("    admin@gallery.au   / Admin123!");
        Console.WriteLine("============================================");
        Console.WriteLine();

        try
        {
            File.WriteAllText(Path.Combine(Directory.GetCurrentDirectory(), "swagger-url.txt"), $"{url}/swagger");
        }
        catch
        {
            // ignore
        }
    }
});

app.Run();

public partial class Program;
