using ArtGallery.Artifacts;
using ArtGallery.Artists;
using ArtGallery.Auth;
using ArtGallery.Exhibitions;
using MongoDB.Driver;

namespace ArtGallery.Persistence;

public static class MongoDbSeeder
{
    public static async Task SeedAsync(ArtGalleryDatabase db)
    {
        await SeedUsersAsync(db);

        if (await db.Artists.CountDocumentsAsync(FilterDefinition<Artist>.Empty) > 0)
            return;

        var now = DateTime.UtcNow;

        var artists = new[]
        {
            new Artist
            {
                Id = 1,
                Name = "Albert Namatjira",
                Community = "Western Arrernte",
                Biography = "Renowned watercolour landscape artist from Central Australia.",
                BirthYear = 1902,
                CreatedAt = now,
                ModifiedAt = now
            },
            new Artist
            {
                Id = 2,
                Name = "Emily Kame Kngwarreye",
                Community = "Anmatyerre",
                Biography = "Celebrated painter known for bold abstract works connected to Country.",
                BirthYear = 1910,
                CreatedAt = now,
                ModifiedAt = now
            },
            new Artist
            {
                Id = 3,
                Name = "Lin Onus",
                Community = "Yorta Yorta",
                Biography = "Artist and activist blending traditional motifs with contemporary techniques.",
                BirthYear = 1948,
                CreatedAt = now,
                ModifiedAt = now
            }
        };

        await db.Artists.InsertManyAsync(artists);

        var artifacts = new[]
        {
            new Artifact
            {
                Id = 1,
                Title = "Ghost Gums, Hermannsburg",
                Medium = "Watercolour on paper",
                YearCreated = 1950,
                Description = "Landscape depicting ghost gums in the Central Desert region.",
                ArtType = "Painting",
                ArtistId = 1,
                CreatedAt = now,
                ModifiedAt = now
            },
            new Artifact
            {
                Id = 2,
                Title = "Earth's Creation",
                Medium = "Synthetic polymer on canvas",
                YearCreated = 1994,
                Description = "Large-scale work expressing ancestral connections to Country.",
                ArtType = "Painting",
                ArtistId = 2,
                CreatedAt = now,
                ModifiedAt = now
            },
            new Artifact
            {
                Id = 3,
                Title = "Ceremonial Coolamon",
                Medium = "Carved wood",
                YearCreated = 1985,
                Description = "Traditional carrying vessel with ochre designs.",
                ArtType = "Sculpture",
                ArtistId = 2,
                CreatedAt = now,
                ModifiedAt = now
            },
            new Artifact
            {
                Id = 4,
                Title = "Barmah Forest",
                Medium = "Synthetic polymer paint on linen",
                YearCreated = 1994,
                Description = "Reflection on Yorta Yorta Country and environmental themes.",
                ArtType = "Painting",
                ArtistId = 3,
                CreatedAt = now,
                ModifiedAt = now
            },
            new Artifact
            {
                Id = 5,
                Title = "Fish Trap at Goulburn River",
                Medium = "Mixed media",
                YearCreated = 1991,
                Description = "Work referencing traditional fishing practices and river Country.",
                ArtType = "Mixed media",
                ArtistId = 3,
                CreatedAt = now,
                ModifiedAt = now
            }
        };

        await db.Artifacts.InsertManyAsync(artifacts);

        var exhibitions = new[]
        {
            new Exhibition
            {
                Id = 1,
                Name = "Stories from Country",
                Description = "A curated selection of paintings and objects celebrating Aboriginal art traditions.",
                StartDate = new DateOnly(2026, 3, 1),
                EndDate = new DateOnly(2026, 6, 30),
                Location = "Main Gallery, Melbourne",
                CreatedAt = now,
                ModifiedAt = now,
                ExhibitionArtifacts =
                {
                    new ExhibitionArtifact { ExhibitionId = 1, ArtifactId = 1, AddedAt = now },
                    new ExhibitionArtifact { ExhibitionId = 1, ArtifactId = 2, AddedAt = now }
                }
            },
            new Exhibition
            {
                Id = 2,
                Name = "Rivers and Homelands",
                Description = "Works exploring connection to water, forest, and ancestral lands.",
                StartDate = new DateOnly(2026, 7, 1),
                EndDate = new DateOnly(2026, 10, 31),
                Location = "Gallery Two, Melbourne",
                CreatedAt = now,
                ModifiedAt = now,
                ExhibitionArtifacts =
                {
                    new ExhibitionArtifact { ExhibitionId = 2, ArtifactId = 4, AddedAt = now },
                    new ExhibitionArtifact { ExhibitionId = 2, ArtifactId = 5, AddedAt = now },
                    new ExhibitionArtifact { ExhibitionId = 2, ArtifactId = 3, AddedAt = now }
                }
            }
        };

        await db.Exhibitions.InsertManyAsync(exhibitions);

        await db.SetSequenceAsync("artist", 3);
        await db.SetSequenceAsync("artifact", 5);
        await db.SetSequenceAsync("exhibition", 2);
    }

    private static async Task SeedUsersAsync(ArtGalleryDatabase db)
    {
        if (await db.Users.CountDocumentsAsync(FilterDefinition<GalleryUser>.Empty) > 0)
            return;

        var hasher = new PasswordService();
        var users = new[]
        {
            CreateUser(hasher, 1, "admin@gallery.au", "Gallery Admin", GalleryRoles.Admin, "Admin123!"),
            CreateUser(hasher, 2, "curator@gallery.au", "Lead Curator", GalleryRoles.Curator, "Curator123!"),
            CreateUser(hasher, 3, "visitor@gallery.au", "Gallery Visitor", GalleryRoles.Visitor, "Visitor123!")
        };

        await db.Users.InsertManyAsync(users);
        await db.SetSequenceAsync("user", 3);
    }

    private static GalleryUser CreateUser(
        PasswordService hasher, int id, string email, string displayName, string role, string password)
    {
        var user = new GalleryUser
        {
            Id = id,
            Email = email,
            DisplayName = displayName,
            Role = role,
            IsActive = true,
            CreatedAt = DateTime.UtcNow
        };
        user.PasswordHash = hasher.Hash(user, password);
        return user;
    }
}
