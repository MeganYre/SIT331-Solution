using ArtGallery.Exhibitions;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace ArtGallery.Tests;

public class ExhibitionsControllerTests
{
    private readonly Mock<IExhibitionRepository> _repo = new();

    [Fact]
    public async Task Create_WhenEndBeforeStart_ReturnsBadRequest()
    {
        var controller = new ExhibitionsController(_repo.Object);
        var result = await controller.Create(new Exhibition
        {
            Name = "Show",
            StartDate = new DateOnly(2026, 6, 1),
            EndDate = new DateOnly(2026, 1, 1)
        });

        Assert.IsType<BadRequestObjectResult>(result.Result);
    }

    [Fact]
    public async Task GetArtifacts_WhenExhibitionMissing_ReturnsNotFound()
    {
        _repo.Setup(r => r.GetByIdAsync(1)).ReturnsAsync((Exhibition?)null);

        var controller = new ExhibitionsController(_repo.Object);
        var result = await controller.GetArtifacts(1);

        Assert.IsType<NotFoundResult>(result);
    }
}
