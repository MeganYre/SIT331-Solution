using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ArtGallery.Auth;

/// <summary>
/// Authentication and membership — JWT login, profile, and admin user registration.
/// </summary>
[ApiController]
[Route("api/auth")]
[Produces("application/json")]
public class AuthController : ControllerBase
{
    private readonly IUserRepository _users;
    private readonly PasswordService _passwords;
    private readonly JwtTokenService _tokens;

    public AuthController(IUserRepository users, PasswordService passwords, JwtTokenService tokens)
    {
        _users = users;
        _passwords = passwords;
        _tokens = tokens;
    }

    /// <summary>Authenticates a user and returns a JWT bearer token.</summary>
    [HttpPost("login")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(AuthResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<AuthResponse>> Login(LoginRequest? request)
    {
        if (request is null || string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.Password))
            return BadRequest("Email and password are required.");

        var user = await _users.GetByEmailAsync(request.Email);
        if (user is null || !user.IsActive || !_passwords.Verify(user, request.Password))
            return Unauthorized(new { error = "Invalid email or password." });

        return Ok(_tokens.CreateToken(user));
    }

    /// <summary>Returns the profile of the currently authenticated user.</summary>
    [HttpGet("me")]
    [Authorize]
    [ProducesResponseType(typeof(UserProfileDto), StatusCodes.Status200OK)]
    public ActionResult<UserProfileDto> Me()
    {
        var id = User.FindFirstValue(ClaimTypes.NameIdentifier);
        var email = User.FindFirstValue(ClaimTypes.Email) ?? string.Empty;
        var name = User.FindFirstValue(ClaimTypes.Name) ?? string.Empty;
        var role = User.FindFirstValue(ClaimTypes.Role) ?? GalleryRoles.Visitor;

        return Ok(new UserProfileDto(int.Parse(id ?? "0"), email, name, role));
    }

    /// <summary>Registers a new gallery account (Visitor self-registration).</summary>
    [HttpPost("register")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(AuthResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<ActionResult<AuthResponse>> RegisterVisitor(RegisterRequest? request)
    {
        if (request is null || string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.Password))
            return BadRequest("Email, password, and display name are required.");

        if (string.IsNullOrWhiteSpace(request.DisplayName))
            return BadRequest("Display name is required.");

        if (request.Password.Length < 8)
            return BadRequest("Password must be at least 8 characters.");

        if (await _users.EmailExistsAsync(request.Email))
            return Conflict("An account with this email already exists.");

        var user = new GalleryUser
        {
            Email = request.Email.Trim(),
            DisplayName = request.DisplayName.Trim(),
            Role = GalleryRoles.Visitor
        };
        user.PasswordHash = _passwords.Hash(user, request.Password);

        var created = await _users.AddAsync(user);
        var response = _tokens.CreateToken(created);
        return Created(string.Empty, response);
    }

    /// <summary>Creates a Curator or Admin account (Admin only).</summary>
    [HttpPost("users")]
    [Authorize(Roles = GalleryRoles.Admin)]
    [ProducesResponseType(typeof(UserProfileDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<ActionResult<UserProfileDto>> CreateUser(RegisterRequest? request)
    {
        if (request is null || string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.Password))
            return BadRequest("Email, password, display name, and role are required.");

        if (string.IsNullOrWhiteSpace(request.DisplayName))
            return BadRequest("Display name is required.");

        if (!GalleryRoles.All.Contains(request.Role))
            return BadRequest($"Role must be one of: {string.Join(", ", GalleryRoles.All)}.");

        if (request.Password.Length < 8)
            return BadRequest("Password must be at least 8 characters.");

        if (await _users.EmailExistsAsync(request.Email))
            return Conflict("An account with this email already exists.");

        var user = new GalleryUser
        {
            Email = request.Email.Trim(),
            DisplayName = request.DisplayName.Trim(),
            Role = request.Role
        };
        user.PasswordHash = _passwords.Hash(user, request.Password);

        var created = await _users.AddAsync(user);
        return Created(string.Empty, new UserProfileDto(created.Id, created.Email, created.DisplayName, created.Role));
    }
}
