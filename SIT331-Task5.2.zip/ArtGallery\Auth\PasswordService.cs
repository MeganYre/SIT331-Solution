using Microsoft.AspNetCore.Identity;

namespace ArtGallery.Auth;

public class PasswordService
{
    private readonly PasswordHasher<GalleryUser> _hasher = new();

    public string Hash(GalleryUser user, string password) =>
        _hasher.HashPassword(user, password);

    public bool Verify(GalleryUser user, string password) =>
        _hasher.VerifyHashedPassword(user, user.PasswordHash, password) != PasswordVerificationResult.Failed;
}
