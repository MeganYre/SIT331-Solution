using ArtGallery.Artifacts;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace ArtGallery.Tests;

public class ArtifactsControllerTests
{
    private readonly Mock<IArtifactRepository> _repo = new();

    [Fact]
    public async Task GetById_WhenFound_ReturnsOk()
    {
        _repo.Setup(r => r.GetByIdAsync(1)).ReturnsAsync(new Artifact { Id = 1, Title = "Work", ArtistId = 1 });

        var controller = new ArtifactsController(_repo.Object);
        var result = await controller.GetById(1);

        Assert.IsType<OkObjectResult>(result.Result);
    }

    [Fact]
    public async Task Create_WhenArtistMissing_ReturnsBadRequest()
    {
        _repo.Setup(r => r.ArtistExistsAsync(99)).ReturnsAsync(false);

        var controller = new ArtifactsController(_repo.Object);
        var result = await controller.Create(new Artifact { Title = "Work", ArtistId = 99 });

        Assert.IsType<BadRequestObjectResult>(result.Result);
    }
}
