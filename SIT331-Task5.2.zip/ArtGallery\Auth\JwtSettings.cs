namespace ArtGallery.Auth;

public class JwtSettings
{
    public string Issuer { get; set; } = "ArtGallery";
    public string Audience { get; set; } = "ArtGalleryWeb";
    public string Key { get; set; } = string.Empty;
    public int ExpirationMinutes { get; set; } = 480;
}
