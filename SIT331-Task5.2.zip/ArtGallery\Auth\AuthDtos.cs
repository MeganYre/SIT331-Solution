namespace ArtGallery.Auth;

public record LoginRequest(string Email, string Password);

public record RegisterRequest(string Email, string Password, string DisplayName, string Role);

public record AuthResponse(
    string Token,
    DateTime ExpiresAt,
    string Email,
    string DisplayName,
    string Role);

public record UserProfileDto(int Id, string Email, string DisplayName, string Role);
