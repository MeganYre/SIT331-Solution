using ArtGallery.Auth;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace ArtGallery.Tests;

public class AuthControllerTests
{
    private readonly Mock<IUserRepository> _users = new();
    private readonly PasswordService _passwords = new();
    private readonly JwtTokenService _tokens;

    public AuthControllerTests()
    {
        var settings = Microsoft.Extensions.Options.Options.Create(new JwtSettings
        {
            Key = "test-signing-key-at-least-32-characters-long",
            Issuer = "Test",
            Audience = "Test"
        });
        _tokens = new JwtTokenService(settings);
    }

    [Fact]
    public async Task Login_WithInvalidCredentials_ReturnsUnauthorized()
    {
        _users.Setup(u => u.GetByEmailAsync("a@b.com")).ReturnsAsync((GalleryUser?)null);

        var controller = new AuthController(_users.Object, _passwords, _tokens);
        var result = await controller.Login(new LoginRequest("a@b.com", "wrong"));

        Assert.IsType<UnauthorizedObjectResult>(result.Result);
    }

    [Fact]
    public async Task Login_WithValidUser_ReturnsToken()
    {
        var user = new GalleryUser
        {
            Id = 1,
            Email = "curator@gallery.au",
            DisplayName = "Curator",
            Role = GalleryRoles.Curator,
            IsActive = true
        };
        user.PasswordHash = _passwords.Hash(user, "Curator123!");

        _users.Setup(u => u.GetByEmailAsync("curator@gallery.au")).ReturnsAsync(user);

        var controller = new AuthController(_users.Object, _passwords, _tokens);
        var result = await controller.Login(new LoginRequest("curator@gallery.au", "Curator123!"));

        var ok = Assert.IsType<OkObjectResult>(result.Result);
        var auth = Assert.IsType<AuthResponse>(ok.Value);
        Assert.False(string.IsNullOrEmpty(auth.Token));
        Assert.Equal(GalleryRoles.Curator, auth.Role);
    }
}
