using System.Text.RegularExpressions;
using ArtGallery.Persistence;
using MongoDB.Bson;
using MongoDB.Driver;

namespace ArtGallery.Artists;

public class ArtistRepository : IArtistRepository
{
    private readonly ArtGalleryDatabase _db;

    public ArtistRepository(ArtGalleryDatabase db)
    {
        _db = db;
    }

    public async Task<List<Artist>> GetAllAsync() =>
        await _db.Artists.Find(FilterDefinition<Artist>.Empty).SortBy(a => a.Name).ToListAsync();

    public async Task<Artist?> GetByIdAsync(int id) =>
        await _db.Artists.Find(a => a.Id == id).FirstOrDefaultAsync();

    public async Task<bool> NameExistsAsync(string name, int? excludeId = null)
    {
        var filter = Builders<Artist>.Filter.Regex(
            a => a.Name,
            new BsonRegularExpression($"^{Regex.Escape(name)}$", "i"));

        if (excludeId.HasValue)
            filter &= Builders<Artist>.Filter.Ne(a => a.Id, excludeId.Value);

        return await _db.Artists.Find(filter).AnyAsync();
    }

    public async Task<Artist> AddAsync(Artist artist)
    {
        var now = DateTime.UtcNow;
        artist.Id = await _db.GetNextIdAsync("artist");
        artist.CreatedAt = now;
        artist.ModifiedAt = now;

        await _db.Artists.InsertOneAsync(artist);
        return artist;
    }

    public async Task<bool> UpdateAsync(int id, Artist artist)
    {
        var update = Builders<Artist>.Update
            .Set(a => a.Name, artist.Name)
            .Set(a => a.Community, artist.Community)
            .Set(a => a.Biography, artist.Biography)
            .Set(a => a.BirthYear, artist.BirthYear)
            .Set(a => a.ModifiedAt, DateTime.UtcNow);

        var result = await _db.Artists.UpdateOneAsync(a => a.Id == id, update);
        return result.MatchedCount > 0;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var hasArtifacts = await _db.Artifacts.Find(a => a.ArtistId == id).AnyAsync();
        if (hasArtifacts)
            return false;

        var result = await _db.Artists.DeleteOneAsync(a => a.Id == id);
        return result.DeletedCount > 0;
    }
}
