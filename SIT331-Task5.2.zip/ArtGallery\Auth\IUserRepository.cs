namespace ArtGallery.Auth;

public interface IUserRepository
{
    Task<GalleryUser?> GetByEmailAsync(string email);
    Task<GalleryUser?> GetByIdAsync(int id);
    Task<GalleryUser> AddAsync(GalleryUser user);
    Task<bool> EmailExistsAsync(string email);
}
