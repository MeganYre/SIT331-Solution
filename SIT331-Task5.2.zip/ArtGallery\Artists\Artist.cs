using MongoDB.Bson.Serialization.Attributes;

namespace ArtGallery.Artists;

/// <summary>
/// Artist bounded context: people who create works held by the gallery.
/// </summary>
[BsonIgnoreExtraElements]
public class Artist
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Community { get; set; }
    public string? Biography { get; set; }
    public int? BirthYear { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime ModifiedAt { get; set; }

    [BsonIgnore]
    public ICollection<Artifacts.Artifact> Artifacts { get; set; } = new List<Artifacts.Artifact>();
}
