using System.Text.RegularExpressions;
using ArtGallery.Persistence;
using MongoDB.Bson;
using MongoDB.Driver;

namespace ArtGallery.Auth;

public class UserRepository : IUserRepository
{
    private readonly ArtGalleryDatabase _db;

    public UserRepository(ArtGalleryDatabase db)
    {
        _db = db;
    }

    public async Task<GalleryUser?> GetByEmailAsync(string email)
    {
        var filter = Builders<GalleryUser>.Filter.Regex(
            u => u.Email,
            new BsonRegularExpression($"^{Regex.Escape(email.Trim())}$", "i"));

        return await _db.Users.Find(filter).FirstOrDefaultAsync();
    }

    public async Task<GalleryUser?> GetByIdAsync(int id) =>
        await _db.Users.Find(u => u.Id == id).FirstOrDefaultAsync();

    public async Task<GalleryUser> AddAsync(GalleryUser user)
    {
        user.Id = await _db.GetNextIdAsync("user");
        user.Email = user.Email.Trim().ToLowerInvariant();
        user.CreatedAt = DateTime.UtcNow;
        await _db.Users.InsertOneAsync(user);
        return user;
    }

    public async Task<bool> EmailExistsAsync(string email) =>
        await GetByEmailAsync(email) is not null;
}
