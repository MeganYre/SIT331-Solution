using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ArtGallery.Artifacts;

/// <summary>
/// Artifacts bounded context — catalogue of works linked to artists.
/// </summary>
[ApiController]
[Route("api/artifacts")]
[Produces("application/json")]
[Authorize(Policy = "CanRead")]
public class ArtifactsController : ControllerBase
{
    private readonly IArtifactRepository _repository;

    public ArtifactsController(IArtifactRepository repository)
    {
        _repository = repository;
    }

    /// <summary>Lists artifacts, optionally filtered by artist.</summary>
    /// <param name="artistId">When set, returns only works by that artist.</param>
    /// <response code="200">Returns matching artifacts.</response>
    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<Artifact>), StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<Artifact>>> GetAll([FromQuery] int? artistId) =>
        Ok(await _repository.GetAllAsync(artistId));

    /// <summary>Gets a single artifact by identifier.</summary>
    /// <param name="id">Artifact identifier.</param>
    /// <response code="200">Artifact found.</response>
    /// <response code="404">Artifact not found.</response>
    [HttpGet("{id:int}", Name = "GetArtifact")]
    [ProducesResponseType(typeof(Artifact), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<Artifact>> GetById(int id)
    {
        var artifact = await _repository.GetByIdAsync(id);
        return artifact is null ? NotFound() : Ok(artifact);
    }

    /// <summary>Registers a new artifact in the collection.</summary>
    /// <param name="artifact">Artifact details; title and valid artist are required.</param>
    /// <response code="201">Artifact created.</response>
    /// <response code="400">Validation failed.</response>
    [HttpPost]
    [Authorize(Policy = "CanWrite")]
    [ProducesResponseType(typeof(Artifact), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<Artifact>> Create(Artifact? artifact)
    {
        if (artifact is null || string.IsNullOrWhiteSpace(artifact.Title))
            return BadRequest("Title is required.");

        if (!await _repository.ArtistExistsAsync(artifact.ArtistId))
            return BadRequest("Artist does not exist.");

        var created = await _repository.AddAsync(artifact);
        return CreatedAtRoute("GetArtifact", new { id = created.Id }, created);
    }

    /// <summary>Updates an existing artifact.</summary>
    /// <param name="id">Artifact identifier.</param>
    /// <param name="artifact">Updated artifact details.</param>
    /// <response code="204">Artifact updated.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="404">Artifact not found.</response>
    [HttpPut("{id:int}")]
    [Authorize(Policy = "CanWrite")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(int id, Artifact? artifact)
    {
        if (artifact is null || string.IsNullOrWhiteSpace(artifact.Title))
            return BadRequest("Title is required.");

        if (await _repository.GetByIdAsync(id) is null)
            return NotFound();

        if (!await _repository.ArtistExistsAsync(artifact.ArtistId))
            return BadRequest("Artist does not exist.");

        var updated = await _repository.UpdateAsync(id, artifact);
        return updated ? NoContent() : NotFound();
    }

    /// <summary>Removes an artifact from the catalogue.</summary>
    /// <param name="id">Artifact identifier.</param>
    /// <response code="204">Artifact deleted.</response>
    /// <response code="404">Artifact not found.</response>
    [HttpDelete("{id:int}")]
    [Authorize(Policy = "CanWrite")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(int id)
    {
        var deleted = await _repository.DeleteAsync(id);
        return deleted ? NoContent() : NotFound();
    }
}
