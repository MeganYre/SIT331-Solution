# Stop old API hosts (fixes "file is locked by .NET Host"), then start.
& "$PSScriptRoot\scripts\stop-api.ps1"
Write-Host "Starting API... (Swagger URL prints below)"
Set-Location $PSScriptRoot
dotnet run
