using MongoDB.Bson.Serialization.Attributes;

namespace ArtGallery.Exhibitions;

[BsonIgnoreExtraElements]
public class ExhibitionArtifact
{
    public int ExhibitionId { get; set; }
    public int ArtifactId { get; set; }
    public DateTime AddedAt { get; set; }
}
