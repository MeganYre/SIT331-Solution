using ArtGallery.Artifacts;
using ArtGallery.Persistence;
using MongoDB.Driver;

namespace ArtGallery.Exhibitions;

public class ExhibitionRepository : IExhibitionRepository
{
    private readonly ArtGalleryDatabase _db;

    public ExhibitionRepository(ArtGalleryDatabase db)
    {
        _db = db;
    }

    public async Task<List<Exhibition>> GetAllAsync() =>
        await _db.Exhibitions.Find(FilterDefinition<Exhibition>.Empty).SortBy(e => e.StartDate).ToListAsync();

    public async Task<Exhibition?> GetByIdAsync(int id) =>
        await _db.Exhibitions.Find(e => e.Id == id).FirstOrDefaultAsync();

    public async Task<List<Artifact>> GetArtifactsAsync(int exhibitionId)
    {
        var exhibition = await GetByIdAsync(exhibitionId);
        if (exhibition is null || exhibition.ExhibitionArtifacts.Count == 0)
            return new List<Artifact>();

        var artifactIds = exhibition.ExhibitionArtifacts.Select(ea => ea.ArtifactId).ToList();
        var artifacts = await _db.Artifacts
            .Find(a => artifactIds.Contains(a.Id))
            .SortBy(a => a.Title)
            .ToListAsync();

        var artistIds = artifacts.Select(a => a.ArtistId).Distinct().ToList();
        var artists = await _db.Artists.Find(a => artistIds.Contains(a.Id)).ToListAsync();
        var lookup = artists.ToDictionary(a => a.Id);

        foreach (var artifact in artifacts)
        {
            if (lookup.TryGetValue(artifact.ArtistId, out var artist))
                artifact.Artist = artist;
        }

        return artifacts;
    }

    public async Task<Exhibition> AddAsync(Exhibition exhibition)
    {
        var now = DateTime.UtcNow;
        exhibition.Id = await _db.GetNextIdAsync("exhibition");
        exhibition.CreatedAt = now;
        exhibition.ModifiedAt = now;
        exhibition.ExhibitionArtifacts ??= new List<ExhibitionArtifact>();

        await _db.Exhibitions.InsertOneAsync(exhibition);
        return exhibition;
    }

    public async Task<bool> UpdateAsync(int id, Exhibition exhibition)
    {
        var update = Builders<Exhibition>.Update
            .Set(e => e.Name, exhibition.Name)
            .Set(e => e.Description, exhibition.Description)
            .Set(e => e.StartDate, exhibition.StartDate)
            .Set(e => e.EndDate, exhibition.EndDate)
            .Set(e => e.Location, exhibition.Location)
            .Set(e => e.ModifiedAt, DateTime.UtcNow);

        var result = await _db.Exhibitions.UpdateOneAsync(e => e.Id == id, update);
        return result.MatchedCount > 0;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var result = await _db.Exhibitions.DeleteOneAsync(e => e.Id == id);
        return result.DeletedCount > 0;
    }

    public async Task<bool> AddArtifactAsync(int exhibitionId, int artifactId)
    {
        var exhibitionExists = await _db.Exhibitions.Find(e => e.Id == exhibitionId).AnyAsync();
        var artifactExists = await _db.Artifacts.Find(a => a.Id == artifactId).AnyAsync();

        if (!exhibitionExists || !artifactExists)
            return false;

        var alreadyLinked = await _db.Exhibitions.Find(
            e => e.Id == exhibitionId && e.ExhibitionArtifacts.Any(ea => ea.ArtifactId == artifactId)).AnyAsync();

        if (alreadyLinked)
            return false;

        var link = new ExhibitionArtifact
        {
            ExhibitionId = exhibitionId,
            ArtifactId = artifactId,
            AddedAt = DateTime.UtcNow
        };

        var update = Builders<Exhibition>.Update
            .Push(e => e.ExhibitionArtifacts, link)
            .Set(e => e.ModifiedAt, DateTime.UtcNow);

        var result = await _db.Exhibitions.UpdateOneAsync(e => e.Id == exhibitionId, update);
        return result.MatchedCount > 0;
    }

    public async Task<bool> RemoveArtifactAsync(int exhibitionId, int artifactId)
    {
        var update = Builders<Exhibition>.Update
            .PullFilter(e => e.ExhibitionArtifacts, ea => ea.ArtifactId == artifactId)
            .Set(e => e.ModifiedAt, DateTime.UtcNow);

        var result = await _db.Exhibitions.UpdateOneAsync(e => e.Id == exhibitionId, update);
        return result.MatchedCount > 0 && result.ModifiedCount > 0;
    }
}
