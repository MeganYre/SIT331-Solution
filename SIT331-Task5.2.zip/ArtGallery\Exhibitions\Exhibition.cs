using MongoDB.Bson.Serialization.Attributes;

namespace ArtGallery.Exhibitions;

/// <summary>
/// Exhibitions bounded context: curated displays of works for visitors.
/// </summary>
[BsonIgnoreExtraElements]
public class Exhibition
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
    public string? Location { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime ModifiedAt { get; set; }

    public List<ExhibitionArtifact> ExhibitionArtifacts { get; set; } = new();
}
