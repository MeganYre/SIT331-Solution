using Microsoft.AspNetCore.Mvc;

namespace ArtGallery.Controllers;

[ApiController]
[Route("/")]
public class HomeController : ControllerBase
{
    [HttpGet]
    public IActionResult Get() =>
        Ok(new
        {
            name = "Art Gallery API",
            task = "SIT331 5.2 HD",
            domain = "Australian Aboriginal Art",
            database = "MongoDB (artgallery)",
            boundedContexts = new[] { "Artists", "Artifacts", "Exhibitions" },
            hdFeatures = new[] { "MongoDB", "xUnit tests", "XML docs", "API key auth", "Web UI", "BRD documentation" },
            swagger = "/swagger",
            webUi = "/index.html",
            health = "/health",
            documentation = "/docs/BRD.md (in repository)",
            endpoints = new
            {
                artists = "/api/artists",
                artifacts = "/api/artifacts",
                exhibitions = "/api/exhibitions"
            },
            apiKeyHeader = "X-Api-Key (when ApiSecurity:Enabled is true)"
        });
}
