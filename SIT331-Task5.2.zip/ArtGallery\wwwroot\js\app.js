const STORAGE_KEY = 'artGalleryAuth';

const state = {
  user: null,
  artists: [],
  artifacts: [],
  exhibitions: [],
  editing: { type: null, id: null },
  exhibitionArtifacts: []
};

function loadSession() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    state.user = JSON.parse(raw);
  } catch {
    localStorage.removeItem(STORAGE_KEY);
  }
}

function saveSession(auth) {
  state.user = {
    token: auth.token,
    email: auth.email,
    displayName: auth.displayName,
    role: auth.role,
    expiresAt: auth.expiresAt
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state.user));
}

function clearSession() {
  state.user = null;
  localStorage.removeItem(STORAGE_KEY);
}

function canWrite() {
  return state.user && (state.user.role === 'Curator' || state.user.role === 'Admin');
}

function isAdmin() {
  return state.user?.role === 'Admin';
}

function authHeaders(json = true) {
  const h = { Authorization: `Bearer ${state.user.token}` };
  if (json) h['Content-Type'] = 'application/json';
  return h;
}

async function api(path, options = {}) {
  const res = await fetch(path, {
    ...options,
    headers: { ...authHeaders(options.body !== undefined), ...(options.headers || {}) }
  });

  if (res.status === 401) {
    clearSession();
    showLogin();
    throw new Error('Session expired. Please sign in again.');
  }

  if (res.status === 204) return null;

  const text = await res.text();
  let data = null;
  if (text) {
    try { data = JSON.parse(text); } catch { data = text; }
  }

  if (!res.ok) {
    const msg = data?.error || data?.title || data || `${res.status} ${res.statusText}`;
    throw new Error(typeof msg === 'string' ? msg : JSON.stringify(msg));
  }

  return data;
}

function showMessage(elId, text, isError = false) {
  const el = document.getElementById(elId);
  if (!el) return;
  el.textContent = text;
  el.className = `msg ${isError ? 'error' : 'ok'}`;
  el.classList.remove('hidden');
  if (!isError) setTimeout(() => el.classList.add('hidden'), 4000);
}

function showLogin() {
  document.getElementById('loginView').classList.remove('hidden');
  document.getElementById('appView').classList.add('hidden');
}

function showApp() {
  document.getElementById('loginView').classList.add('hidden');
  document.getElementById('appView').classList.remove('hidden');
  document.getElementById('userName').textContent = state.user.displayName;
  document.getElementById('userRole').textContent = state.user.role;
  document.getElementById('userEmail').textContent = state.user.email;
  document.querySelectorAll('.write-only').forEach(el => {
    el.classList.toggle('hidden', !canWrite());
  });
  document.getElementById('adminPanel').classList.toggle('hidden', !isAdmin());
}

async function login(email, password) {
  const auth = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  }).then(async r => {
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.error || 'Login failed');
    return data;
  });

  saveSession(auth);
  showApp();
  await refreshAll();
}

async function register(displayName, email, password) {
  const auth = await fetch('/api/auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ displayName, email, password, role: 'Visitor' })
  }).then(async r => {
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.error || data.title || 'Registration failed');
    return data;
  });

  saveSession(auth);
  showApp();
  await refreshAll();
}

async function refreshAll() {
  const [artists, artifacts, exhibitions] = await Promise.all([
    api('/api/artists'),
    api('/api/artifacts'),
    api('/api/exhibitions')
  ]);
  state.artists = artists;
  state.artifacts = artifacts;
  state.exhibitions = exhibitions;
  renderArtists();
  renderArtifacts();
  renderExhibitions();
  populateArtistSelects();
  populateExhibitionSelect();
}

function renderArtists() {
  const tbody = document.querySelector('#artistsTable tbody');
  tbody.innerHTML = state.artists.map(a => `
    <tr>
      <td>${a.id}</td>
      <td><strong>${esc(a.name)}</strong></td>
      <td>${esc(a.community || '—')}</td>
      <td>${a.birthYear ?? '—'}</td>
      <td class="actions write-only">
        <button type="button" data-edit-artist="${a.id}">Edit</button>
        <button type="button" class="danger" data-del-artist="${a.id}">Delete</button>
      </td>
    </tr>`).join('');
  document.querySelectorAll('.write-only').forEach(el => el.classList.toggle('hidden', !canWrite()));
}

function renderArtifacts() {
  const tbody = document.querySelector('#artifactsTable tbody');
  const artistName = id => state.artists.find(a => a.id === id)?.name || `#${id}`;
  tbody.innerHTML = state.artifacts.map(a => `
    <tr>
      <td>${a.id}</td>
      <td><strong>${esc(a.title)}</strong></td>
      <td>${esc(a.artType || '—')}</td>
      <td>${esc(artistName(a.artistId))}</td>
      <td>${a.yearCreated ?? '—'}</td>
      <td class="actions write-only">
        <button type="button" data-edit-artifact="${a.id}">Edit</button>
        <button type="button" class="danger" data-del-artifact="${a.id}">Delete</button>
      </td>
    </tr>`).join('');
  document.querySelectorAll('.write-only').forEach(el => el.classList.toggle('hidden', !canWrite()));
}

function renderExhibitions() {
  const tbody = document.querySelector('#exhibitionsTable tbody');
  tbody.innerHTML = state.exhibitions.map(e => `
    <tr>
      <td>${e.id}</td>
      <td><strong>${esc(e.name)}</strong></td>
      <td>${e.startDate} → ${e.endDate}</td>
      <td>${esc(e.location || '—')}</td>
      <td>${e.exhibitionArtifacts?.length ?? 0} works</td>
      <td class="actions">
        <button type="button" data-view-exhibition="${e.id}">Works</button>
        <span class="write-only">
          <button type="button" data-edit-exhibition="${e.id}">Edit</button>
          <button type="button" class="danger" data-del-exhibition="${e.id}">Delete</button>
        </span>
      </td>
    </tr>`).join('');
  document.querySelectorAll('.write-only').forEach(el => el.classList.toggle('hidden', !canWrite()));
}

function populateArtistSelects() {
  const opts = state.artists.map(a => `<option value="${a.id}">${esc(a.name)}</option>`).join('');
  document.getElementById('artifactArtistId').innerHTML = `<option value="">Select artist…</option>${opts}`;
}

function populateExhibitionSelect() {
  const sel = document.getElementById('linkExhibitionId');
  sel.innerHTML = state.exhibitions.map(e => `<option value="${e.id}">${esc(e.name)}</option>`).join('');
  if (state.exhibitions.length) loadExhibitionArtifacts(state.exhibitions[0].id);
}

async function loadExhibitionArtifacts(exhibitionId) {
  const list = await api(`/api/exhibitions/${exhibitionId}/artifacts`);
  state.exhibitionArtifacts = list;
  const ul = document.getElementById('exhibitionWorksList');
  const inShow = new Set(list.map(x => x.artifactId));
  const available = state.artifacts.filter(a => !inShow.has(a.id));

  ul.innerHTML = list.length
    ? list.map(x => {
        const art = state.artifacts.find(a => a.id === x.artifactId);
        return `<li>${esc(art?.title || 'Artifact #' + x.artifactId)}
          <button type="button" class="danger write-only" data-unlink="${exhibitionId}:${x.artifactId}">Remove</button></li>`;
      }).join('')
    : '<li class="sub">No works in this exhibition yet.</li>';

  document.getElementById('linkArtifactId').innerHTML = available.length
    ? available.map(a => `<option value="${a.id}">${esc(a.title)}</option>`).join('')
    : '<option value="">All works already linked</option>';

  document.querySelectorAll('.write-only').forEach(el => el.classList.toggle('hidden', !canWrite()));
}

function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function switchTab(name) {
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.toggle('active', p.id === `tab-${name}`));
}

function clearArtistForm() {
  state.editing = { type: null, id: null };
  document.getElementById('artistForm').reset();
  document.getElementById('artistFormTitle').textContent = 'Add artist';
}

function clearArtifactForm() {
  state.editing = { type: null, id: null };
  document.getElementById('artifactForm').reset();
  document.getElementById('artifactFormTitle').textContent = 'Add artifact';
}

function clearExhibitionForm() {
  state.editing = { type: null, id: null };
  document.getElementById('exhibitionForm').reset();
  document.getElementById('exhibitionFormTitle').textContent = 'Add exhibition';
}

document.addEventListener('DOMContentLoaded', () => {
  loadSession();

  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => switchTab(tab.dataset.tab));
  });

  document.getElementById('loginForm').addEventListener('submit', async e => {
    e.preventDefault();
    try {
      await login(
        document.getElementById('loginEmail').value.trim(),
        document.getElementById('loginPassword').value
      );
      showMessage('loginMsg', `Welcome, ${state.user.displayName}!`);
    } catch (err) {
      showMessage('loginMsg', err.message, true);
    }
  });

  document.getElementById('registerForm').addEventListener('submit', async e => {
    e.preventDefault();
    try {
      await register(
        document.getElementById('regName').value.trim(),
        document.getElementById('regEmail').value.trim(),
        document.getElementById('regPassword').value
      );
      showMessage('loginMsg', 'Account created. You are signed in as Visitor.');
    } catch (err) {
      showMessage('loginMsg', err.message, true);
    }
  });

  document.getElementById('logoutBtn').addEventListener('click', () => {
    clearSession();
    showLogin();
  });

  document.getElementById('artistForm').addEventListener('submit', async e => {
    e.preventDefault();
    if (!canWrite()) return;
    const body = {
      name: document.getElementById('artistName').value.trim(),
      community: document.getElementById('artistCommunity').value.trim() || null,
      biography: document.getElementById('artistBio').value.trim() || null,
      birthYear: parseInt(document.getElementById('artistBirthYear').value, 10) || null
    };
    try {
      if (state.editing.type === 'artist') {
        await api(`/api/artists/${state.editing.id}`, { method: 'PUT', body: JSON.stringify(body) });
      } else {
        await api('/api/artists', { method: 'POST', body: JSON.stringify(body) });
      }
      clearArtistForm();
      await refreshAll();
      showMessage('appMsg', 'Artist saved.');
    } catch (err) { showMessage('appMsg', err.message, true); }
  });

  document.getElementById('artifactForm').addEventListener('submit', async e => {
    e.preventDefault();
    if (!canWrite()) return;
    const body = {
      title: document.getElementById('artifactTitle').value.trim(),
      artType: document.getElementById('artifactType').value.trim() || null,
      medium: document.getElementById('artifactMedium').value.trim() || null,
      yearCreated: parseInt(document.getElementById('artifactYear').value, 10) || null,
      description: document.getElementById('artifactDesc').value.trim() || null,
      artistId: parseInt(document.getElementById('artifactArtistId').value, 10)
    };
    try {
      if (state.editing.type === 'artifact') {
        await api(`/api/artifacts/${state.editing.id}`, { method: 'PUT', body: JSON.stringify(body) });
      } else {
        await api('/api/artifacts', { method: 'POST', body: JSON.stringify(body) });
      }
      clearArtifactForm();
      await refreshAll();
      showMessage('appMsg', 'Artifact saved.');
    } catch (err) { showMessage('appMsg', err.message, true); }
  });

  document.getElementById('exhibitionForm').addEventListener('submit', async e => {
    e.preventDefault();
    if (!canWrite()) return;
    const body = {
      name: document.getElementById('exhibitionName').value.trim(),
      description: document.getElementById('exhibitionDesc').value.trim() || null,
      location: document.getElementById('exhibitionLocation').value.trim() || null,
      startDate: document.getElementById('exhibitionStart').value,
      endDate: document.getElementById('exhibitionEnd').value
    };
    try {
      if (state.editing.type === 'exhibition') {
        await api(`/api/exhibitions/${state.editing.id}`, { method: 'PUT', body: JSON.stringify(body) });
      } else {
        await api('/api/exhibitions', { method: 'POST', body: JSON.stringify(body) });
      }
      clearExhibitionForm();
      await refreshAll();
      showMessage('appMsg', 'Exhibition saved.');
    } catch (err) { showMessage('appMsg', err.message, true); }
  });

  document.getElementById('linkExhibitionId').addEventListener('change', e => {
    loadExhibitionArtifacts(parseInt(e.target.value, 10));
  });

  document.getElementById('linkArtifactBtn').addEventListener('click', async () => {
    if (!canWrite()) return;
    const exId = parseInt(document.getElementById('linkExhibitionId').value, 10);
    const artId = parseInt(document.getElementById('linkArtifactId').value, 10);
    if (!artId) return;
    try {
      await api(`/api/exhibitions/${exId}/artifacts/${artId}`, { method: 'POST' });
      await refreshAll();
      await loadExhibitionArtifacts(exId);
      showMessage('appMsg', 'Work added to exhibition.');
    } catch (err) { showMessage('appMsg', err.message, true); }
  });

  document.getElementById('adminUserForm').addEventListener('submit', async e => {
    e.preventDefault();
    if (!isAdmin()) return;
    const body = {
      displayName: document.getElementById('newUserName').value.trim(),
      email: document.getElementById('newUserEmail').value.trim(),
      password: document.getElementById('newUserPassword').value,
      role: document.getElementById('newUserRole').value
    };
    try {
      await api('/api/auth/users', { method: 'POST', body: JSON.stringify(body) });
      document.getElementById('adminUserForm').reset();
      showMessage('appMsg', `User ${body.email} created as ${body.role}.`);
    } catch (err) { showMessage('appMsg', err.message, true); }
  });

  document.getElementById('appView').addEventListener('click', async e => {
    const t = e.target;
    if (t.dataset.editArtist) {
      const a = state.artists.find(x => x.id === parseInt(t.dataset.editArtist, 10));
      if (!a) return;
      state.editing = { type: 'artist', id: a.id };
      document.getElementById('artistFormTitle').textContent = 'Edit artist';
      document.getElementById('artistName').value = a.name;
      document.getElementById('artistCommunity').value = a.community || '';
      document.getElementById('artistBio').value = a.biography || '';
      document.getElementById('artistBirthYear').value = a.birthYear || '';
      switchTab('artists');
    }
    if (t.dataset.delArtist && confirm('Delete this artist?')) {
      try {
        await api(`/api/artists/${t.dataset.delArtist}`, { method: 'DELETE' });
        await refreshAll();
      } catch (err) { showMessage('appMsg', err.message, true); }
    }
    if (t.dataset.editArtifact) {
      const a = state.artifacts.find(x => x.id === parseInt(t.dataset.editArtifact, 10));
      if (!a) return;
      state.editing = { type: 'artifact', id: a.id };
      document.getElementById('artifactFormTitle').textContent = 'Edit artifact';
      document.getElementById('artifactTitle').value = a.title;
      document.getElementById('artifactType').value = a.artType || '';
      document.getElementById('artifactMedium').value = a.medium || '';
      document.getElementById('artifactYear').value = a.yearCreated || '';
      document.getElementById('artifactDesc').value = a.description || '';
      document.getElementById('artifactArtistId').value = a.artistId;
      switchTab('artifacts');
    }
    if (t.dataset.delArtifact && confirm('Delete this artifact?')) {
      try {
        await api(`/api/artifacts/${t.dataset.delArtifact}`, { method: 'DELETE' });
        await refreshAll();
      } catch (err) { showMessage('appMsg', err.message, true); }
    }
    if (t.dataset.editExhibition) {
      const ex = state.exhibitions.find(x => x.id === parseInt(t.dataset.editExhibition, 10));
      if (!ex) return;
      state.editing = { type: 'exhibition', id: ex.id };
      document.getElementById('exhibitionFormTitle').textContent = 'Edit exhibition';
      document.getElementById('exhibitionName').value = ex.name;
      document.getElementById('exhibitionDesc').value = ex.description || '';
      document.getElementById('exhibitionLocation').value = ex.location || '';
      document.getElementById('exhibitionStart').value = ex.startDate;
      document.getElementById('exhibitionEnd').value = ex.endDate;
      switchTab('exhibitions');
    }
    if (t.dataset.delExhibition && confirm('Delete this exhibition?')) {
      try {
        await api(`/api/exhibitions/${t.dataset.delExhibition}`, { method: 'DELETE' });
        await refreshAll();
      } catch (err) { showMessage('appMsg', err.message, true); }
    }
    if (t.dataset.viewExhibition) {
      document.getElementById('linkExhibitionId').value = t.dataset.viewExhibition;
      await loadExhibitionArtifacts(parseInt(t.dataset.viewExhibition, 10));
      switchTab('exhibitions');
    }
    if (t.dataset.unlink) {
      const [exId, artId] = t.dataset.unlink.split(':');
      try {
        await api(`/api/exhibitions/${exId}/artifacts/${artId}`, { method: 'DELETE' });
        await refreshAll();
        await loadExhibitionArtifacts(parseInt(exId, 10));
      } catch (err) { showMessage('appMsg', err.message, true); }
    }
  });

  document.getElementById('cancelArtist').addEventListener('click', clearArtistForm);
  document.getElementById('cancelArtifact').addEventListener('click', clearArtifactForm);
  document.getElementById('cancelExhibition').addEventListener('click', clearExhibitionForm);

  if (state.user?.token) {
    showApp();
    refreshAll().catch(err => showMessage('appMsg', err.message, true));
  } else {
    showLogin();
  }
});
