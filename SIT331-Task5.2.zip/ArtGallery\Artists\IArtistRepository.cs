namespace ArtGallery.Artists;

public interface IArtistRepository
{
    Task<List<Artist>> GetAllAsync();
    Task<Artist?> GetByIdAsync(int id);
    Task<bool> NameExistsAsync(string name, int? excludeId = null);
    Task<Artist> AddAsync(Artist artist);
    Task<bool> UpdateAsync(int id, Artist artist);
    Task<bool> DeleteAsync(int id);
}
