using ArtGallery.Persistence;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace ArtGallery.Infrastructure;

public class MongoHealthCheck : IHealthCheck
{
    private readonly ArtGalleryDatabase _database;

    public MongoHealthCheck(ArtGalleryDatabase database)
    {
        _database = database;
    }

    public async Task<HealthCheckResult> CheckHealthAsync(
        HealthCheckContext context,
        CancellationToken cancellationToken = default)
    {
        try
        {
            await _database.Artists.CountDocumentsAsync(
                MongoDB.Driver.FilterDefinition<Artists.Artist>.Empty,
                cancellationToken: cancellationToken);
            return HealthCheckResult.Healthy("MongoDB is reachable.");
        }
        catch (Exception ex)
        {
            return HealthCheckResult.Unhealthy("MongoDB is not reachable.", ex);
        }
    }
}
