using ArtGallery.Artifacts;
using ArtGallery.Artists;
using ArtGallery.Auth;
using ArtGallery.Exhibitions;
using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace ArtGallery.Persistence;

public class ArtGalleryDatabase
{
    private readonly IMongoCollection<SequenceCounter> _counters;

    public ArtGalleryDatabase(IOptions<MongoDbSettings> settings)
    {
        var clientSettings = MongoClientSettings.FromConnectionString(settings.Value.ConnectionString);
        clientSettings.ServerSelectionTimeout = TimeSpan.FromSeconds(5);
        var client = new MongoClient(clientSettings);
        var database = client.GetDatabase(settings.Value.DatabaseName);

        Artists = database.GetCollection<Artist>("artists");
        Artifacts = database.GetCollection<Artifact>("artifacts");
        Exhibitions = database.GetCollection<Exhibition>("exhibitions");
        Users = database.GetCollection<GalleryUser>("users");
        _counters = database.GetCollection<SequenceCounter>("counters");

        Artists.Indexes.CreateOne(
            new CreateIndexModel<Artist>(
                Builders<Artist>.IndexKeys.Ascending(a => a.Name),
                new CreateIndexOptions { Unique = true }));

        Artifacts.Indexes.CreateOne(
            new CreateIndexModel<Artifact>(Builders<Artifact>.IndexKeys.Ascending(a => a.ArtistId)));

        Exhibitions.Indexes.CreateOne(
            new CreateIndexModel<Exhibition>(Builders<Exhibition>.IndexKeys.Ascending(e => e.StartDate)));

        Users.Indexes.CreateOne(
            new CreateIndexModel<GalleryUser>(
                Builders<GalleryUser>.IndexKeys.Ascending(u => u.Email),
                new CreateIndexOptions { Unique = true }));
    }

    public IMongoCollection<Artist> Artists { get; }
    public IMongoCollection<Artifact> Artifacts { get; }
    public IMongoCollection<Exhibition> Exhibitions { get; }
    public IMongoCollection<GalleryUser> Users { get; }

    public async Task<int> GetNextIdAsync(string sequenceName)
    {
        var filter = Builders<SequenceCounter>.Filter.Eq(c => c.Id, sequenceName);
        var update = Builders<SequenceCounter>.Update.Inc(c => c.Value, 1);
        var options = new FindOneAndUpdateOptions<SequenceCounter>
        {
            IsUpsert = true,
            ReturnDocument = ReturnDocument.After
        };

        var counter = await _counters.FindOneAndUpdateAsync(filter, update, options);
        return counter.Value;
    }

    public Task SetSequenceAsync(string sequenceName, int value) =>
        _counters.ReplaceOneAsync(
            Builders<SequenceCounter>.Filter.Eq(c => c.Id, sequenceName),
            new SequenceCounter { Id = sequenceName, Value = value },
            new ReplaceOptions { IsUpsert = true });

    private class SequenceCounter
    {
        public string Id { get; set; } = string.Empty;
        public int Value { get; set; }
    }
}
