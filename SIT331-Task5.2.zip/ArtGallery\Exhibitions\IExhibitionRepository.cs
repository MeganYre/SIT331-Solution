using ArtGallery.Artifacts;

namespace ArtGallery.Exhibitions;

public interface IExhibitionRepository
{
    Task<List<Exhibition>> GetAllAsync();
    Task<Exhibition?> GetByIdAsync(int id);
    Task<List<Artifact>> GetArtifactsAsync(int exhibitionId);
    Task<Exhibition> AddAsync(Exhibition exhibition);
    Task<bool> UpdateAsync(int id, Exhibition exhibition);
    Task<bool> DeleteAsync(int id);
    Task<bool> AddArtifactAsync(int exhibitionId, int artifactId);
    Task<bool> RemoveArtifactAsync(int exhibitionId, int artifactId);
}
