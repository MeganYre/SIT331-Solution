using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ArtGallery.Artists;

/// <summary>
/// Artists bounded context — manages creators of works in the Aboriginal art collection.
/// </summary>
[ApiController]
[Route("api/artists")]
[Produces("application/json")]
[Authorize(Policy = "CanRead")]
public class ArtistsController : ControllerBase
{
    private readonly IArtistRepository _repository;

    public ArtistsController(IArtistRepository repository)
    {
        _repository = repository;
    }

    /// <summary>Lists all artists ordered by name.</summary>
    /// <response code="200">Returns the artist collection.</response>
    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<Artist>), StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<Artist>>> GetAll() =>
        Ok(await _repository.GetAllAsync());

    /// <summary>Gets a single artist by identifier.</summary>
    /// <param name="id">Artist identifier.</param>
    /// <response code="200">Artist found.</response>
    /// <response code="404">Artist not found.</response>
    [HttpGet("{id:int}", Name = "GetArtist")]
    [ProducesResponseType(typeof(Artist), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<Artist>> GetById(int id)
    {
        var artist = await _repository.GetByIdAsync(id);
        return artist is null ? NotFound() : Ok(artist);
    }

    /// <summary>Registers a new artist in the collection.</summary>
    /// <param name="artist">Artist details; name is required.</param>
    /// <response code="201">Artist created.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="409">Artist name already exists.</response>
    [HttpPost]
    [Authorize(Policy = "CanWrite")]
    [ProducesResponseType(typeof(Artist), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<ActionResult<Artist>> Create(Artist? artist)
    {
        if (artist is null || string.IsNullOrWhiteSpace(artist.Name))
            return BadRequest("Name is required.");

        if (await _repository.NameExistsAsync(artist.Name))
            return Conflict("An artist with this name already exists.");

        var created = await _repository.AddAsync(artist);
        return CreatedAtRoute("GetArtist", new { id = created.Id }, created);
    }

    /// <summary>Updates an existing artist.</summary>
    /// <param name="id">Artist identifier.</param>
    /// <param name="artist">Updated artist details.</param>
    /// <response code="204">Artist updated.</response>
    /// <response code="404">Artist not found.</response>
    [HttpPut("{id:int}")]
    [Authorize(Policy = "CanWrite")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Update(int id, Artist? artist)
    {
        if (artist is null || string.IsNullOrWhiteSpace(artist.Name))
            return BadRequest("Name is required.");

        if (await _repository.GetByIdAsync(id) is null)
            return NotFound();

        if (await _repository.NameExistsAsync(artist.Name, id))
            return Conflict("An artist with this name already exists.");

        var updated = await _repository.UpdateAsync(id, artist);
        return updated ? NoContent() : NotFound();
    }

    /// <summary>Removes an artist who has no artifacts in the collection.</summary>
    /// <param name="id">Artist identifier.</param>
    /// <response code="204">Artist deleted.</response>
    /// <response code="404">Artist not found.</response>
    /// <response code="409">Artist still has artifacts.</response>
    [HttpDelete("{id:int}")]
    [Authorize(Policy = "CanWrite")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Delete(int id)
    {
        var deleted = await _repository.DeleteAsync(id);
        if (!deleted && await _repository.GetByIdAsync(id) is not null)
            return Conflict("Cannot delete an artist who still has artifacts in the collection.");

        return deleted ? NoContent() : NotFound();
    }
}
