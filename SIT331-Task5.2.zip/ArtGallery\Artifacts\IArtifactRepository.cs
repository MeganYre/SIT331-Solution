namespace ArtGallery.Artifacts;

public interface IArtifactRepository
{
    Task<List<Artifact>> GetAllAsync(int? artistId = null);
    Task<Artifact?> GetByIdAsync(int id);
    Task<bool> ArtistExistsAsync(int artistId);
    Task<Artifact> AddAsync(Artifact artifact);
    Task<bool> UpdateAsync(int id, Artifact artifact);
    Task<bool> DeleteAsync(int id);
}
