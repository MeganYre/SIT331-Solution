using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ArtGallery.Exhibitions;

/// <summary>
/// Exhibitions bounded context — curated shows and their included artifacts.
/// </summary>
[ApiController]
[Route("api/exhibitions")]
[Produces("application/json")]
[Authorize(Policy = "CanRead")]
public class ExhibitionsController : ControllerBase
{
    private readonly IExhibitionRepository _repository;

    public ExhibitionsController(IExhibitionRepository repository)
    {
        _repository = repository;
    }

    /// <summary>Lists all exhibitions ordered by start date.</summary>
    /// <response code="200">Returns the exhibition collection.</response>
    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<Exhibition>), StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<Exhibition>>> GetAll() =>
        Ok(await _repository.GetAllAsync());

    /// <summary>Gets a single exhibition by identifier.</summary>
    /// <param name="id">Exhibition identifier.</param>
    /// <response code="200">Exhibition found.</response>
    /// <response code="404">Exhibition not found.</response>
    [HttpGet("{id:int}", Name = "GetExhibition")]
    [ProducesResponseType(typeof(Exhibition), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<Exhibition>> GetById(int id)
    {
        var exhibition = await _repository.GetByIdAsync(id);
        return exhibition is null ? NotFound() : Ok(exhibition);
    }

    /// <summary>Lists artifacts assigned to an exhibition.</summary>
    /// <param name="id">Exhibition identifier.</param>
    /// <response code="200">Returns exhibition artifacts.</response>
    /// <response code="404">Exhibition not found.</response>
    [HttpGet("{id:int}/artifacts")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetArtifacts(int id)
    {
        if (await _repository.GetByIdAsync(id) is null)
            return NotFound();

        return Ok(await _repository.GetArtifactsAsync(id));
    }

    /// <summary>Creates a new exhibition.</summary>
    /// <param name="exhibition">Exhibition details; name and valid date range are required.</param>
    /// <response code="201">Exhibition created.</response>
    /// <response code="400">Validation failed.</response>
    [HttpPost]
    [Authorize(Policy = "CanWrite")]
    [ProducesResponseType(typeof(Exhibition), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<Exhibition>> Create(Exhibition? exhibition)
    {
        if (exhibition is null || string.IsNullOrWhiteSpace(exhibition.Name))
            return BadRequest("Name is required.");

        if (exhibition.EndDate < exhibition.StartDate)
            return BadRequest("End date must be on or after start date.");

        var created = await _repository.AddAsync(exhibition);
        return CreatedAtRoute("GetExhibition", new { id = created.Id }, created);
    }

    /// <summary>Updates an existing exhibition.</summary>
    /// <param name="id">Exhibition identifier.</param>
    /// <param name="exhibition">Updated exhibition details.</param>
    /// <response code="204">Exhibition updated.</response>
    /// <response code="400">Validation failed.</response>
    /// <response code="404">Exhibition not found.</response>
    [HttpPut("{id:int}")]
    [Authorize(Policy = "CanWrite")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(int id, Exhibition? exhibition)
    {
        if (exhibition is null || string.IsNullOrWhiteSpace(exhibition.Name))
            return BadRequest("Name is required.");

        if (exhibition.EndDate < exhibition.StartDate)
            return BadRequest("End date must be on or after start date.");

        if (await _repository.GetByIdAsync(id) is null)
            return NotFound();

        var updated = await _repository.UpdateAsync(id, exhibition);
        return updated ? NoContent() : NotFound();
    }

    /// <summary>Deletes an exhibition.</summary>
    /// <param name="id">Exhibition identifier.</param>
    /// <response code="204">Exhibition deleted.</response>
    /// <response code="404">Exhibition not found.</response>
    [HttpDelete("{id:int}")]
    [Authorize(Policy = "CanWrite")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(int id)
    {
        var deleted = await _repository.DeleteAsync(id);
        return deleted ? NoContent() : NotFound();
    }

    /// <summary>Adds an artifact to an exhibition.</summary>
    /// <param name="exhibitionId">Exhibition identifier.</param>
    /// <param name="artifactId">Artifact identifier.</param>
    /// <response code="204">Artifact added.</response>
    /// <response code="404">Exhibition not found.</response>
    /// <response code="409">Artifact missing or already in exhibition.</response>
    [HttpPost("{exhibitionId:int}/artifacts/{artifactId:int}")]
    [Authorize(Policy = "CanWrite")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> AddArtifact(int exhibitionId, int artifactId)
    {
        if (await _repository.GetByIdAsync(exhibitionId) is null)
            return NotFound("Exhibition not found.");

        if (!await _repository.AddArtifactAsync(exhibitionId, artifactId))
            return Conflict("Artifact is already in this exhibition or does not exist.");

        return NoContent();
    }

    /// <summary>Removes an artifact from an exhibition.</summary>
    /// <param name="exhibitionId">Exhibition identifier.</param>
    /// <param name="artifactId">Artifact identifier.</param>
    /// <response code="204">Artifact removed.</response>
    /// <response code="404">Exhibition or link not found.</response>
    [HttpDelete("{exhibitionId:int}/artifacts/{artifactId:int}")]
    [Authorize(Policy = "CanWrite")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> RemoveArtifact(int exhibitionId, int artifactId)
    {
        var removed = await _repository.RemoveArtifactAsync(exhibitionId, artifactId);
        return removed ? NoContent() : NotFound();
    }
}
