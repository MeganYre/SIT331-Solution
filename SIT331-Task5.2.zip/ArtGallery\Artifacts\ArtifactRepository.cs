using ArtGallery.Persistence;
using MongoDB.Driver;

namespace ArtGallery.Artifacts;

public class ArtifactRepository : IArtifactRepository
{
    private readonly ArtGalleryDatabase _db;

    public ArtifactRepository(ArtGalleryDatabase db)
    {
        _db = db;
    }

    public async Task<List<Artifact>> GetAllAsync(int? artistId = null)
    {
        var filter = artistId.HasValue
            ? Builders<Artifact>.Filter.Eq(a => a.ArtistId, artistId.Value)
            : FilterDefinition<Artifact>.Empty;

        var artifacts = await _db.Artifacts.Find(filter).SortBy(a => a.Title).ToListAsync();
        await AttachArtistsAsync(artifacts);
        return artifacts;
    }

    public async Task<Artifact?> GetByIdAsync(int id)
    {
        var artifact = await _db.Artifacts.Find(a => a.Id == id).FirstOrDefaultAsync();
        if (artifact is null)
            return null;

        artifact.Artist = await _db.Artists.Find(a => a.Id == artifact.ArtistId).FirstOrDefaultAsync();
        return artifact;
    }

    public Task<bool> ArtistExistsAsync(int artistId) =>
        _db.Artists.Find(a => a.Id == artistId).AnyAsync();

    public async Task<Artifact> AddAsync(Artifact artifact)
    {
        var now = DateTime.UtcNow;
        artifact.Id = await _db.GetNextIdAsync("artifact");
        artifact.CreatedAt = now;
        artifact.ModifiedAt = now;

        await _db.Artifacts.InsertOneAsync(artifact);
        return artifact;
    }

    public async Task<bool> UpdateAsync(int id, Artifact artifact)
    {
        var update = Builders<Artifact>.Update
            .Set(a => a.Title, artifact.Title)
            .Set(a => a.Medium, artifact.Medium)
            .Set(a => a.YearCreated, artifact.YearCreated)
            .Set(a => a.Description, artifact.Description)
            .Set(a => a.ArtType, artifact.ArtType)
            .Set(a => a.ArtistId, artifact.ArtistId)
            .Set(a => a.ModifiedAt, DateTime.UtcNow);

        var result = await _db.Artifacts.UpdateOneAsync(a => a.Id == id, update);
        return result.MatchedCount > 0;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var result = await _db.Artifacts.DeleteOneAsync(a => a.Id == id);
        return result.DeletedCount > 0;
    }

    private async Task AttachArtistsAsync(List<Artifact> artifacts)
    {
        var artistIds = artifacts.Select(a => a.ArtistId).Distinct().ToList();
        var artists = await _db.Artists.Find(a => artistIds.Contains(a.Id)).ToListAsync();
        var lookup = artists.ToDictionary(a => a.Id);

        foreach (var artifact in artifacts)
        {
            if (lookup.TryGetValue(artifact.ArtistId, out var artist))
                artifact.Artist = artist;
        }
    }
}
