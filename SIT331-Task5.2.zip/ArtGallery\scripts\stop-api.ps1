# Stops any process still hosting ArtGallery (fixes MSB3027 DLL file lock).
Get-Process -Name ArtGallery -ErrorAction SilentlyContinue |
    Stop-Process -Force -ErrorAction SilentlyContinue

Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
    Where-Object {
        $_.Name -eq 'dotnet.exe' -and
        $_.CommandLine -like '*ArtGallery*'
    } |
    ForEach-Object {
        Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
    }

Start-Sleep -Milliseconds 800
