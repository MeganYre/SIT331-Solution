using ArtGallery.Artists;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace ArtGallery.Tests;

public class ArtistsControllerTests
{
    private readonly Mock<IArtistRepository> _repo = new();

    [Fact]
    public async Task GetAll_ReturnsOkWithArtists()
    {
        _repo.Setup(r => r.GetAllAsync()).ReturnsAsync(new List<Artist>
        {
            new() { Id = 1, Name = "Test Artist" }
        });

        var controller = new ArtistsController(_repo.Object);
        var result = await controller.GetAll();

        var ok = Assert.IsType<OkObjectResult>(result.Result);
        var list = Assert.IsAssignableFrom<IEnumerable<Artist>>(ok.Value);
        Assert.Single(list);
    }

    [Fact]
    public async Task GetById_WhenMissing_ReturnsNotFound()
    {
        _repo.Setup(r => r.GetByIdAsync(99)).ReturnsAsync((Artist?)null);

        var controller = new ArtistsController(_repo.Object);
        var result = await controller.GetById(99);

        Assert.IsType<NotFoundResult>(result.Result);
    }

    [Fact]
    public async Task Create_WhenNameMissing_ReturnsBadRequest()
    {
        var controller = new ArtistsController(_repo.Object);
        var result = await controller.Create(new Artist { Name = "  " });

        Assert.IsType<BadRequestObjectResult>(result.Result);
    }

    [Fact]
    public async Task Create_WhenDuplicateName_ReturnsConflict()
    {
        _repo.Setup(r => r.NameExistsAsync("Existing", null)).ReturnsAsync(true);

        var controller = new ArtistsController(_repo.Object);
        var result = await controller.Create(new Artist { Name = "Existing" });

        Assert.IsType<ConflictObjectResult>(result.Result);
    }

    [Fact]
    public async Task Create_WhenValid_ReturnsCreated()
    {
        _repo.Setup(r => r.NameExistsAsync("New", null)).ReturnsAsync(false);
        _repo.Setup(r => r.AddAsync(It.IsAny<Artist>())).ReturnsAsync(new Artist { Id = 5, Name = "New" });

        var controller = new ArtistsController(_repo.Object);
        var result = await controller.Create(new Artist { Name = "New" });

        Assert.IsType<CreatedAtRouteResult>(result.Result);
    }

    [Fact]
    public async Task Delete_WhenHasArtifacts_ReturnsConflict()
    {
        _repo.Setup(r => r.DeleteAsync(1)).ReturnsAsync(false);
        _repo.Setup(r => r.GetByIdAsync(1)).ReturnsAsync(new Artist { Id = 1, Name = "A" });

        var controller = new ArtistsController(_repo.Object);
        var result = await controller.Delete(1);

        Assert.IsType<ConflictObjectResult>(result);
    }
}
