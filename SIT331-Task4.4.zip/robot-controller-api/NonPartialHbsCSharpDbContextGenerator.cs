using System.Text;
using EntityFrameworkCore.Scaffolding.Handlebars;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Scaffolding;
using Microsoft.Extensions.Options;

namespace robot_controller_api;

/// <summary>
/// Generates a non-partial DbContext: removes EF's OnModelCreatingPartial hook so DbContext.hbs can use "public class".
/// </summary>
public class NonPartialHbsCSharpDbContextGenerator : HbsCSharpDbContextGenerator
{
    public NonPartialHbsCSharpDbContextGenerator(
        IProviderConfigurationCodeGenerator providerConfigurationCodeGenerator,
        IAnnotationCodeGenerator annotationCodeGenerator,
        IDbContextTemplateService dbContextTemplateService,
        IEntityTypeTransformationService entityTypeTransformationService,
        ICSharpHelper cSharpHelper,
        IOptions<HandlebarsScaffoldingOptions> options)
        : base(
            providerConfigurationCodeGenerator,
            annotationCodeGenerator,
            dbContextTemplateService,
            entityTypeTransformationService,
            cSharpHelper,
            options)
    {
    }

    protected override void GenerateOnModelCreating(IModel model)
    {
        base.GenerateOnModelCreating(model);

        if (!TemplateData.TryGetValue("on-model-creating", out var value) || value is not string onModelCreating)
        {
            return;
        }

        TemplateData["on-model-creating"] = RemoveOnModelCreatingPartialHook(onModelCreating);
    }

    private static string RemoveOnModelCreatingPartialHook(string onModelCreating)
    {
        var sb = new StringBuilder();
        using var reader = new StringReader(onModelCreating);
        string? line;
        while ((line = reader.ReadLine()) is not null)
        {
            var trimmed = line.Trim();
            if (trimmed is "OnModelCreatingPartial(modelBuilder);"
                or "partial void OnModelCreatingPartial(ModelBuilder modelBuilder);")
            {
                continue;
            }

            sb.AppendLine(line);
        }

        return sb.ToString();
    }
}
