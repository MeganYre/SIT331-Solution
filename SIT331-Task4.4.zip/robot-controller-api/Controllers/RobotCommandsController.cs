using Microsoft.AspNetCore.Mvc;
using robot_controller_api.Persistence;

namespace robot_controller_api.Controllers;

[ApiController]
[Route("api/robot-commands")]
public class RobotCommandsController : ControllerBase
{
    private readonly IRobotCommandDataAccess _robotCommandsRepo;

    public RobotCommandsController(IRobotCommandDataAccess robotCommandsRepo)
    {
        _robotCommandsRepo = robotCommandsRepo;
    }

    [HttpGet]
    public IEnumerable<RobotCommand> GetAllRobotCommands() =>
        _robotCommandsRepo.GetRobotCommands();

    [HttpGet("move")]
    public IEnumerable<RobotCommand> GetMoveCommandsOnly() =>
        _robotCommandsRepo.GetRobotCommands().Where(c => c.IsMoveCommand);

    [HttpGet("{id}", Name = "GetRobotCommand")]
    public IActionResult GetRobotCommandById(int id)
    {
        var command = _robotCommandsRepo.GetRobotCommandById(id);
        if (command is null)
            return NotFound();

        return Ok(command);
    }

    [HttpPost]
    public IActionResult AddRobotCommand(RobotCommand? newCommand)
    {
        if (newCommand is null)
            return BadRequest();

        if (string.IsNullOrWhiteSpace(newCommand.Name))
            return BadRequest();

        if (_robotCommandsRepo.RobotCommandNameExists(newCommand.Name))
            return Conflict();

        var command = _robotCommandsRepo.InsertRobotCommand(newCommand);

        return CreatedAtRoute("GetRobotCommand", new { id = command.Id }, command);
    }

    [HttpPut("{id}")]
    public IActionResult UpdateRobotCommand(int id, RobotCommand? updatedCommand)
    {
        if (updatedCommand is null)
            return BadRequest();

        var existing = _robotCommandsRepo.GetRobotCommandById(id);
        if (existing is null)
            return NotFound();

        if (string.IsNullOrWhiteSpace(updatedCommand.Name))
            return BadRequest();

        if (_robotCommandsRepo.RobotCommandNameExists(updatedCommand.Name, id))
            return BadRequest();

        var updated = _robotCommandsRepo.UpdateRobotCommand(id, updatedCommand);
        if (!updated)
            return NotFound();

        return NoContent();
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteRobotCommand(int id)
    {
        var deleted = _robotCommandsRepo.DeleteRobotCommand(id);
        if (!deleted)
            return NotFound();

        return NoContent();
    }
}
