using Microsoft.AspNetCore.Mvc;
using robot_controller_api.Persistence;

namespace robot_controller_api.Controllers;

[ApiController]
[Route("api/maps")]
public class MapsController : ControllerBase
{
    private readonly IMapDataAccess _mapsRepo;

    public MapsController(IMapDataAccess mapsRepo)
    {
        _mapsRepo = mapsRepo;
    }

    [HttpGet]
    public IEnumerable<Map> GetAllMaps() => _mapsRepo.GetMaps();

    [HttpGet("square")]
    public IEnumerable<Map> GetSquareMapsOnly() => _mapsRepo.GetSquareMaps();

    [HttpGet("{id}", Name = "GetMap")]
    public IActionResult GetMapById(int id)
    {
        var map = _mapsRepo.GetMapById(id);
        return map is null ? NotFound() : Ok(map);
    }

    [HttpPost]
    public IActionResult AddMap(Map? newMap)
    {
        if (newMap is null)
            return BadRequest();

        if (string.IsNullOrWhiteSpace(newMap.Name))
            return BadRequest();

        if (_mapsRepo.MapNameExists(newMap.Name))
            return Conflict();

        var map = _mapsRepo.InsertMap(newMap);

        return CreatedAtRoute("GetMap", new { id = map.Id }, map);
    }

    [HttpPut("{id}")]
    public IActionResult UpdateMap(int id, Map? updatedMap)
    {
        if (updatedMap is null)
            return BadRequest();

        var existing = _mapsRepo.GetMapById(id);
        if (existing is null)
            return NotFound();

        if (string.IsNullOrWhiteSpace(updatedMap.Name))
            return BadRequest();

        if (_mapsRepo.MapNameExists(updatedMap.Name, id))
            return BadRequest();

        var updated = _mapsRepo.UpdateMap(id, updatedMap);
        if (!updated)
            return NotFound();

        return NoContent();
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteMap(int id)
    {
        var deleted = _mapsRepo.DeleteMap(id);
        if (!deleted)
            return NotFound();

        return NoContent();
    }

    // Endpoint 7
    [HttpGet("{id}/{x}-{y}")]
    public IActionResult CheckCoordinate(int id, int x, int y)
    {
        if (x < 0 || y < 0)
            return BadRequest();

        var map = _mapsRepo.GetMapById(id);
        if (map is null)
            return NotFound();

        // Match task-sheet semantics: Columns -> X bound, Rows -> Y bound.
        var isOnMap = x >= 0 && y >= 0 && x < map.Columns && y < map.Rows;
        return Ok(isOnMap);
    }
}
