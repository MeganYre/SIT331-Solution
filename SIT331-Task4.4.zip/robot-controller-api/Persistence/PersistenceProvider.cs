namespace robot_controller_api.Persistence;

public static class PersistenceProvider
{
    public const string Ef = "EF";
    public const string Ado = "ADO";
    public const string Repository = "Repository";

    public static string Normalize(string? value) =>
        value?.Trim().ToUpperInvariant() switch
        {
            "EF" or "ENTITYFRAMEWORK" or "ENTITY_FRAMEWORK" => Ef,
            "ADO" or "ADO.NET" => Ado,
            "REPOSITORY" or "FASTMEMBER" => Repository,
            _ => Ef,
        };
}
