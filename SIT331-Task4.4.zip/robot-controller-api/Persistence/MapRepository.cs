using Npgsql;

namespace robot_controller_api.Persistence;

public class MapRepository : IMapDataAccess, IRepository
{
    private IRepository _repo => this;

    public List<Map> GetMaps() =>
        _repo.ExecuteReader<Map>(
            @"SELECT id, columns, rows, name, description, created_date, modified_date, is_square FROM maps ORDER BY id");

    public List<Map> GetSquareMaps() =>
        _repo.ExecuteReader<Map>(
            @"SELECT id, columns, rows, name, description, created_date, modified_date, is_square FROM maps WHERE columns = rows ORDER BY id");

    public Map? GetMapById(int id)
    {
        var rows = _repo.ExecuteReader<Map>(
            @"SELECT id, columns, rows, name, description, created_date, modified_date, is_square FROM maps WHERE id = @id",
            new[] { new NpgsqlParameter("id", id) });
        return rows.FirstOrDefault();
    }

    public bool MapNameExists(string name, int? excludeId = null)
    {
        var sql = @"SELECT COUNT(1) FROM maps WHERE LOWER(name) = LOWER(@name)";
        var pars = new List<NpgsqlParameter> { new("name", name) };
        if (excludeId.HasValue)
        {
            sql += " AND id <> @excludeId";
            pars.Add(new NpgsqlParameter("excludeId", excludeId.Value));
        }

        return _repo.ExecuteScalarInt64(sql, pars.ToArray()) > 0;
    }

    public Map InsertMap(Map map)
    {
        var now = DateTime.UtcNow;
        var sql = @"INSERT INTO maps (columns, rows, name, description, created_date, modified_date)
              VALUES (@columns, @rows, @name, @description, @created_date, @modified_date)
              RETURNING id, columns, rows, name, description, created_date, modified_date, is_square";
        var pars = new NpgsqlParameter[]
        {
            new("columns", map.Columns),
            new("rows", map.Rows),
            new("name", map.Name),
            new("description", (object?)map.Description ?? DBNull.Value),
            new("created_date", now),
            new("modified_date", now),
        };
        return _repo.ExecuteReader<Map>(sql, pars).Single();
    }

    public bool UpdateMap(int id, Map map)
    {
        var sql = @"UPDATE maps
              SET columns = @columns,
                  rows = @rows,
                  name = @name,
                  description = @description,
                  modified_date = @modified_date
              WHERE id = @id";
        var pars = new NpgsqlParameter[]
        {
            new("id", id),
            new("columns", map.Columns),
            new("rows", map.Rows),
            new("name", map.Name),
            new("description", (object?)map.Description ?? DBNull.Value),
            new("modified_date", DateTime.UtcNow),
        };
        return _repo.ExecuteNonQuery(sql, pars) > 0;
    }

    public bool DeleteMap(int id) =>
        _repo.ExecuteNonQuery("DELETE FROM maps WHERE id = @id", new[] { new NpgsqlParameter("id", id) }) > 0;
}
