namespace robot_controller_api.Persistence;

// Set from configuration in Program.cs at startup (used by ADO, repositories, and EF design-time fallback).
internal static class DbConnectionString
{
    internal static string Value { get; set; } =
        "Host=localhost;Database=sit331;Username=postgres;Password=2809";
}
