namespace robot_controller_api.Persistence;

public interface IMapDataAccess
{
    List<Map> GetMaps();
    List<Map> GetSquareMaps();
    Map? GetMapById(int id);
    bool MapNameExists(string name, int? excludeId = null);
    Map InsertMap(Map map);
    bool UpdateMap(int id, Map map);
    bool DeleteMap(int id);
}
