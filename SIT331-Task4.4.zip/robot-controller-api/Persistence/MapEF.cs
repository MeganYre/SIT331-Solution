using Microsoft.EntityFrameworkCore;

namespace robot_controller_api.Persistence;

public class MapEF : IMapDataAccess
{
    private readonly RobotContext _context;

    public MapEF(RobotContext context)
    {
        _context = context;
    }

    public List<Map> GetMaps() =>
        _context.Maps
            .AsNoTracking()
            .OrderBy(m => m.Id)
            .ToList();

    public List<Map> GetSquareMaps() =>
        _context.Maps
            .AsNoTracking()
            .Where(m => m.Columns == m.Rows)
            .OrderBy(m => m.Id)
            .ToList();

    public Map? GetMapById(int id) =>
        _context.Maps
            .AsNoTracking()
            .FirstOrDefault(m => m.Id == id);

    public bool MapNameExists(string name, int? excludeId = null)
    {
        var query = _context.Maps.AsQueryable();
        if (excludeId.HasValue)
            query = query.Where(m => m.Id != excludeId.Value);

        return query.Any(m => EF.Functions.ILike(m.Name, name));
    }

    public Map InsertMap(Map map)
    {
        var now = DateTime.Now;
        map.CreatedDate = now;
        map.ModifiedDate = now;

        _context.Maps.Add(map);
        _context.SaveChanges();

        return map;
    }

    public bool UpdateMap(int id, Map map)
    {
        var existing = _context.Maps.FirstOrDefault(m => m.Id == id);
        if (existing is null)
            return false;

        existing.Columns = map.Columns;
        existing.Rows = map.Rows;
        existing.Name = map.Name;
        existing.Description = map.Description;
        existing.ModifiedDate = DateTime.Now;

        return _context.SaveChanges() > 0;
    }

    public bool DeleteMap(int id)
    {
        var existing = _context.Maps.FirstOrDefault(m => m.Id == id);
        if (existing is null)
            return false;

        _context.Maps.Remove(existing);
        return _context.SaveChanges() > 0;
    }
}
