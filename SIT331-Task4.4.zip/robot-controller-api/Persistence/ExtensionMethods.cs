using FastMember;
using Npgsql;

namespace robot_controller_api.Persistence;

public static class ExtensionMethods
{
    private static string NormalizeMemberName(string value) =>
        string.Concat(value.Where(ch => ch != '_')).ToUpperInvariant();

    public static void MapTo<T>(this NpgsqlDataReader dr, T entity) where T : class
    {
        if (entity == null)
            throw new ArgumentNullException(nameof(entity));

        var fastMember = TypeAccessor.Create(entity.GetType());
        var props = fastMember
            .GetMembers()
            .ToDictionary(member => NormalizeMemberName(member.Name), member => member.Name, StringComparer.Ordinal);

        for (var i = 0; i < dr.FieldCount; i++)
        {
            var normalizedColumnName = NormalizeMemberName(dr.GetName(i));
            if (props.TryGetValue(normalizedColumnName, out var prop))
                fastMember[entity, prop] = dr.IsDBNull(i) ? null! : dr.GetValue(i);
        }
    }
}
