using Npgsql;

namespace robot_controller_api.Persistence;

public class RobotCommandADO : IRobotCommandDataAccess
{
    public List<RobotCommand> GetRobotCommands()
    {
        var commands = new List<RobotCommand>();
        using var conn = new NpgsqlConnection(DbConnectionString.Value);
        conn.Open();

        using var cmd = new NpgsqlCommand(
            "SELECT id, name, description, is_move_command, created_date, modified_date FROM robot_commands ORDER BY id",
            conn);
        using var dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            var cmdEntity = new RobotCommand();
            dr.MapTo(cmdEntity);
            commands.Add(cmdEntity);
        }

        return commands;
    }

    public RobotCommand? GetRobotCommandById(int id)
    {
        using var conn = new NpgsqlConnection(DbConnectionString.Value);
        conn.Open();

        using var cmd = new NpgsqlCommand(
            "SELECT id, name, description, is_move_command, created_date, modified_date FROM robot_commands WHERE id = @id",
            conn);
        cmd.Parameters.AddWithValue("id", id);

        using var dr = cmd.ExecuteReader();
        if (!dr.Read())
            return null;
        var command = new RobotCommand();
        dr.MapTo(command);
        return command;
    }

    public bool RobotCommandNameExists(string name, int? excludeId = null)
    {
        using var conn = new NpgsqlConnection(DbConnectionString.Value);
        conn.Open();

        var sql = "SELECT COUNT(1) FROM robot_commands WHERE LOWER(name) = LOWER(@name)";
        if (excludeId.HasValue)
        {
            sql += " AND id <> @excludeId";
        }

        using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("name", name);
        if (excludeId.HasValue)
        {
            cmd.Parameters.AddWithValue("excludeId", excludeId.Value);
        }

        var count = (long)cmd.ExecuteScalar()!;
        return count > 0;
    }

    public RobotCommand InsertRobotCommand(RobotCommand command)
    {
        using var conn = new NpgsqlConnection(DbConnectionString.Value);
        conn.Open();

        using var cmd = new NpgsqlCommand(
            @"INSERT INTO robot_commands (name, description, is_move_command, created_date, modified_date)
              VALUES (@name, @description, @is_move_command, @created_date, @modified_date)
              RETURNING id, name, description, is_move_command, created_date, modified_date",
            conn);

        var now = DateTime.UtcNow;
        cmd.Parameters.AddWithValue("name", command.Name);
        cmd.Parameters.AddWithValue("description", (object?)command.Description ?? DBNull.Value);
        cmd.Parameters.AddWithValue("is_move_command", command.IsMoveCommand);
        cmd.Parameters.AddWithValue("created_date", now);
        cmd.Parameters.AddWithValue("modified_date", now);

        using var dr = cmd.ExecuteReader();
        dr.Read();
        var inserted = new RobotCommand();
        dr.MapTo(inserted);
        return inserted;
    }

    public bool UpdateRobotCommand(int id, RobotCommand command)
    {
        using var conn = new NpgsqlConnection(DbConnectionString.Value);
        conn.Open();

        using var cmd = new NpgsqlCommand(
            @"UPDATE robot_commands
              SET name = @name,
                  description = @description,
                  is_move_command = @is_move_command,
                  modified_date = @modified_date
              WHERE id = @id",
            conn);

        cmd.Parameters.AddWithValue("id", id);
        cmd.Parameters.AddWithValue("name", command.Name);
        cmd.Parameters.AddWithValue("description", (object?)command.Description ?? DBNull.Value);
        cmd.Parameters.AddWithValue("is_move_command", command.IsMoveCommand);
        cmd.Parameters.AddWithValue("modified_date", DateTime.UtcNow);

        return cmd.ExecuteNonQuery() > 0;
    }

    public bool DeleteRobotCommand(int id)
    {
        using var conn = new NpgsqlConnection(DbConnectionString.Value);
        conn.Open();

        using var cmd = new NpgsqlCommand("DELETE FROM robot_commands WHERE id = @id", conn);
        cmd.Parameters.AddWithValue("id", id);

        return cmd.ExecuteNonQuery() > 0;
    }
}
