namespace robot_controller_api.Persistence;

public interface IRobotCommandDataAccess
{
    List<RobotCommand> GetRobotCommands();
    RobotCommand? GetRobotCommandById(int id);
    bool RobotCommandNameExists(string name, int? excludeId = null);
    RobotCommand InsertRobotCommand(RobotCommand command);
    bool UpdateRobotCommand(int id, RobotCommand command);
    bool DeleteRobotCommand(int id);
}
