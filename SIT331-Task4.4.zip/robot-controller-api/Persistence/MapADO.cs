using Npgsql;

namespace robot_controller_api.Persistence;

public class MapADO : IMapDataAccess
{
    public List<Map> GetMaps()
    {
        var maps = new List<Map>();
        using var conn = new NpgsqlConnection(DbConnectionString.Value);
        conn.Open();

        using var cmd = new NpgsqlCommand(
            "SELECT id, columns, rows, name, description, created_date, modified_date, is_square FROM maps ORDER BY id",
            conn);
        using var dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            var m = new Map();
            dr.MapTo(m);
            maps.Add(m);
        }

        return maps;
    }

    public List<Map> GetSquareMaps()
    {
        var maps = new List<Map>();
        using var conn = new NpgsqlConnection(DbConnectionString.Value);
        conn.Open();

        using var cmd = new NpgsqlCommand(
            "SELECT id, columns, rows, name, description, created_date, modified_date, is_square FROM maps WHERE columns = rows ORDER BY id",
            conn);
        using var dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            var m = new Map();
            dr.MapTo(m);
            maps.Add(m);
        }

        return maps;
    }

    public Map? GetMapById(int id)
    {
        using var conn = new NpgsqlConnection(DbConnectionString.Value);
        conn.Open();

        using var cmd = new NpgsqlCommand(
            "SELECT id, columns, rows, name, description, created_date, modified_date, is_square FROM maps WHERE id = @id",
            conn);
        cmd.Parameters.AddWithValue("id", id);

        using var dr = cmd.ExecuteReader();
        if (!dr.Read())
            return null;
        var map = new Map();
        dr.MapTo(map);
        return map;
    }

    public bool MapNameExists(string name, int? excludeId = null)
    {
        using var conn = new NpgsqlConnection(DbConnectionString.Value);
        conn.Open();

        var sql = "SELECT COUNT(1) FROM maps WHERE LOWER(name) = LOWER(@name)";
        if (excludeId.HasValue)
        {
            sql += " AND id <> @excludeId";
        }

        using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("name", name);
        if (excludeId.HasValue)
        {
            cmd.Parameters.AddWithValue("excludeId", excludeId.Value);
        }

        var count = (long)cmd.ExecuteScalar()!;
        return count > 0;
    }

    public Map InsertMap(Map map)
    {
        using var conn = new NpgsqlConnection(DbConnectionString.Value);
        conn.Open();

        using var cmd = new NpgsqlCommand(
            @"INSERT INTO maps (columns, rows, name, description, created_date, modified_date)
              VALUES (@columns, @rows, @name, @description, @created_date, @modified_date)
              RETURNING id, columns, rows, name, description, created_date, modified_date, is_square",
            conn);

        var now = DateTime.UtcNow;
        cmd.Parameters.AddWithValue("columns", map.Columns);
        cmd.Parameters.AddWithValue("rows", map.Rows);
        cmd.Parameters.AddWithValue("name", map.Name);
        cmd.Parameters.AddWithValue("description", (object?)map.Description ?? DBNull.Value);
        cmd.Parameters.AddWithValue("created_date", now);
        cmd.Parameters.AddWithValue("modified_date", now);

        using var dr = cmd.ExecuteReader();
        dr.Read();
        var inserted = new Map();
        dr.MapTo(inserted);
        return inserted;
    }

    public bool UpdateMap(int id, Map map)
    {
        using var conn = new NpgsqlConnection(DbConnectionString.Value);
        conn.Open();

        using var cmd = new NpgsqlCommand(
            @"UPDATE maps
              SET columns = @columns,
                  rows = @rows,
                  name = @name,
                  description = @description,
                  modified_date = @modified_date
              WHERE id = @id",
            conn);

        cmd.Parameters.AddWithValue("id", id);
        cmd.Parameters.AddWithValue("columns", map.Columns);
        cmd.Parameters.AddWithValue("rows", map.Rows);
        cmd.Parameters.AddWithValue("name", map.Name);
        cmd.Parameters.AddWithValue("description", (object?)map.Description ?? DBNull.Value);
        cmd.Parameters.AddWithValue("modified_date", DateTime.UtcNow);

        return cmd.ExecuteNonQuery() > 0;
    }

    public bool DeleteMap(int id)
    {
        using var conn = new NpgsqlConnection(DbConnectionString.Value);
        conn.Open();

        using var cmd = new NpgsqlCommand("DELETE FROM maps WHERE id = @id", conn);
        cmd.Parameters.AddWithValue("id", id);

        return cmd.ExecuteNonQuery() > 0;
    }
}
