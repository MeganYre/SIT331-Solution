using Microsoft.EntityFrameworkCore;

namespace robot_controller_api.Persistence;

public class RobotCommandEF : IRobotCommandDataAccess
{
    private readonly RobotContext _context;

    public RobotCommandEF(RobotContext context)
    {
        _context = context;
    }

    public List<RobotCommand> GetRobotCommands() =>
        _context.RobotCommands
            .AsNoTracking()
            .OrderBy(c => c.Id)
            .ToList();

    public RobotCommand? GetRobotCommandById(int id) =>
        _context.RobotCommands
            .AsNoTracking()
            .FirstOrDefault(c => c.Id == id);

    public bool RobotCommandNameExists(string name, int? excludeId = null)
    {
        var query = _context.RobotCommands.AsQueryable();
        if (excludeId.HasValue)
            query = query.Where(c => c.Id != excludeId.Value);

        return query.Any(c => EF.Functions.ILike(c.Name, name));
    }

    public RobotCommand InsertRobotCommand(RobotCommand command)
    {
        var now = DateTime.Now;
        command.CreatedDate = now;
        command.ModifiedDate = now;

        _context.RobotCommands.Add(command);
        _context.SaveChanges();

        return command;
    }

    public bool UpdateRobotCommand(int id, RobotCommand command)
    {
        var existing = _context.RobotCommands.FirstOrDefault(c => c.Id == id);
        if (existing is null)
            return false;

        existing.Name = command.Name;
        existing.Description = command.Description;
        existing.IsMoveCommand = command.IsMoveCommand;
        existing.ModifiedDate = DateTime.Now;

        return _context.SaveChanges() > 0;
    }

    public bool DeleteRobotCommand(int id)
    {
        var existing = _context.RobotCommands.FirstOrDefault(c => c.Id == id);
        if (existing is null)
            return false;

        _context.RobotCommands.Remove(existing);
        return _context.SaveChanges() > 0;
    }
}
