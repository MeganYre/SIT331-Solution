using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace robot_controller_api.Persistence;

public class RobotContextFactory : IDesignTimeDbContextFactory<RobotContext>
{
    public RobotContext CreateDbContext(string[] args)
    {
        var configuration = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: false)
            .AddJsonFile("appsettings.Development.json", optional: true)
            .Build();

        var connectionString = configuration.GetConnectionString("Sit331") ?? DbConnectionString.Value;

        var optionsBuilder = new DbContextOptionsBuilder<RobotContext>();
        optionsBuilder.UseNpgsql(connectionString);

        return new RobotContext(optionsBuilder.Options);
    }
}
