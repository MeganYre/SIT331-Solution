using Npgsql;

namespace robot_controller_api.Persistence;

public interface IRepository
{
    List<T> ExecuteReader<T>(string sqlCommand, NpgsqlParameter[]? dbParams = null) where T : class, new()
    {
        var entities = new List<T>();
        using var conn = new NpgsqlConnection(DbConnectionString.Value);
        conn.Open();
        using var cmd = new NpgsqlCommand(sqlCommand, conn);
        if (dbParams is not null)
        {
            cmd.Parameters.AddRange(dbParams.Where(x => x.Value is not null).ToArray());
        }

        using var dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            var entity = new T();
            dr.MapTo(entity);
            entities.Add(entity);
        }

        return entities;
    }

    long ExecuteScalarInt64(string sqlCommand, NpgsqlParameter[]? dbParams = null)
    {
        using var conn = new NpgsqlConnection(DbConnectionString.Value);
        conn.Open();
        using var cmd = new NpgsqlCommand(sqlCommand, conn);
        if (dbParams is not null)
        {
            cmd.Parameters.AddRange(dbParams.Where(x => x.Value is not null).ToArray());
        }

        return (long)cmd.ExecuteScalar()!;
    }

    int ExecuteNonQuery(string sqlCommand, NpgsqlParameter[]? dbParams = null)
    {
        using var conn = new NpgsqlConnection(DbConnectionString.Value);
        conn.Open();
        using var cmd = new NpgsqlCommand(sqlCommand, conn);
        if (dbParams is not null)
        {
            cmd.Parameters.AddRange(dbParams.Where(x => x.Value is not null).ToArray());
        }

        return cmd.ExecuteNonQuery();
    }
}
