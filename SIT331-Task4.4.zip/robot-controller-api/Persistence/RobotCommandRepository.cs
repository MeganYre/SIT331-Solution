using Npgsql;

namespace robot_controller_api.Persistence;

public class RobotCommandRepository : IRobotCommandDataAccess, IRepository
{
    private IRepository _repo => this;

    public List<RobotCommand> GetRobotCommands() =>
        _repo.ExecuteReader<RobotCommand>(
            @"SELECT id, name, description, is_move_command, created_date, modified_date FROM robot_commands ORDER BY id");

    public RobotCommand? GetRobotCommandById(int id)
    {
        var rows = _repo.ExecuteReader<RobotCommand>(
            @"SELECT id, name, description, is_move_command, created_date, modified_date FROM robot_commands WHERE id = @id",
            new[] { new NpgsqlParameter("id", id) });
        return rows.FirstOrDefault();
    }

    public bool RobotCommandNameExists(string name, int? excludeId = null)
    {
        var sql = @"SELECT COUNT(1) FROM robot_commands WHERE LOWER(name) = LOWER(@name)";
        var pars = new List<NpgsqlParameter> { new("name", name) };
        if (excludeId.HasValue)
        {
            sql += " AND id <> @excludeId";
            pars.Add(new NpgsqlParameter("excludeId", excludeId.Value));
        }

        return _repo.ExecuteScalarInt64(sql, pars.ToArray()) > 0;
    }

    public RobotCommand InsertRobotCommand(RobotCommand command)
    {
        var now = DateTime.UtcNow;
        var sql = @"INSERT INTO robot_commands (name, description, is_move_command, created_date, modified_date)
              VALUES (@name, @description, @is_move_command, @created_date, @modified_date)
              RETURNING id, name, description, is_move_command, created_date, modified_date";
        var pars = new NpgsqlParameter[]
        {
            new("name", command.Name),
            new("description", (object?)command.Description ?? DBNull.Value),
            new("is_move_command", command.IsMoveCommand),
            new("created_date", now),
            new("modified_date", now),
        };
        return _repo.ExecuteReader<RobotCommand>(sql, pars).Single();
    }

    public bool UpdateRobotCommand(int id, RobotCommand command)
    {
        var sql = @"UPDATE robot_commands
              SET name = @name,
                  description = @description,
                  is_move_command = @is_move_command,
                  modified_date = @modified_date
              WHERE id = @id";
        var pars = new NpgsqlParameter[]
        {
            new("id", id),
            new("name", command.Name),
            new("description", (object?)command.Description ?? DBNull.Value),
            new("is_move_command", command.IsMoveCommand),
            new("modified_date", DateTime.UtcNow),
        };
        return _repo.ExecuteNonQuery(sql, pars) > 0;
    }

    public bool DeleteRobotCommand(int id) =>
        _repo.ExecuteNonQuery("DELETE FROM robot_commands WHERE id = @id", new[] { new NpgsqlParameter("id", id) }) > 0;
}
