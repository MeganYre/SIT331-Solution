CREATE TABLE public.maps (
    id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    columns integer NOT NULL,
    rows integer NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(800),
    created_date timestamp without time zone NOT NULL,
    modified_date timestamp without time zone NOT NULL,
    is_square boolean GENERATED ALWAYS AS (((rows > 0) AND (rows = columns))) STORED
);

CREATE TABLE public.robot_commands (
    id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name character varying(50) NOT NULL,
    description character varying(800),
    is_move_command boolean NOT NULL,
    created_date timestamp without time zone NOT NULL,
    modified_date timestamp without time zone NOT NULL
);
