using EntityFrameworkCore.Scaffolding.Handlebars;
using EntityFrameworkCore.Scaffolding.Handlebars.Helpers;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace robot_controller_api;

public class ScaffoldingDesignTimeServices : IDesignTimeServices
{
    public void ConfigureDesignTimeServices(IServiceCollection services)
    {
        services.AddHandlebarsScaffolding(options =>
        {
            options.ExcludedTables = new List<string> { "map", "robotcommand", "user" };
        });

        var dbContextGeneratorInterface = typeof(HbsCSharpDbContextGenerator)
            .GetInterfaces()
            .Single(i => i.Name == "ICSharpDbContextGenerator");
        services.Replace(ServiceDescriptor.Singleton(dbContextGeneratorInterface, typeof(NonPartialHbsCSharpDbContextGenerator)));

        services.AddHandlebarsTransformers(propertyTransformer: p =>
        {
            var name = ToPascalCasePropertyName(p.PropertyName);
            return name == p.PropertyName
                ? p
                : new EntityPropertyInfo(p.PropertyType, name, p.PropertyIsNullable);
        });
    }

    /// <summary>snake_case and legacy scaffold names → PascalCase (CreatedDate, IsMoveCommand).</summary>
    internal static string ToPascalCasePropertyName(string name)
    {
        if (string.IsNullOrEmpty(name))
        {
            return name;
        }

        if (name.Contains('_', StringComparison.Ordinal))
        {
            var parts = name.Split('_', StringSplitOptions.RemoveEmptyEntries);
            return string.Concat(parts.Select(static part =>
                part.Length == 0
                    ? string.Empty
                    : char.ToUpperInvariant(part[0]) + part[1..].ToLowerInvariant()));
        }

        return name switch
        {
            "Ismovecommand" => "IsMoveCommand",
            "Createddate" => "CreatedDate",
            "Modifieddate" => "ModifiedDate",
            "Issquare" => "IsSquare",
            _ when char.IsLower(name[0]) => char.ToUpperInvariant(name[0]) + name[1..],
            _ => name,
        };
    }
}
