global using robot_controller_api.Models;
