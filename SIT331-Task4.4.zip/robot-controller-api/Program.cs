using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using robot_controller_api.Persistence;

var builder = WebApplication.CreateBuilder(args);

DbConnectionString.Value = builder.Configuration.GetConnectionString("Sit331")
    ?? DbConnectionString.Value;

builder.Services.AddControllers();

// appsettings.Development.json only loads when ASPNETCORE_ENVIRONMENT=Development (see launchSettings.json).
// Override without editing files: set ROBOT_API_PERSISTENCE=ADO or Repository before dotnet run.
var persistenceSource = Environment.GetEnvironmentVariable("ROBOT_API_PERSISTENCE");
var persistence = PersistenceProvider.Normalize(persistenceSource ?? builder.Configuration["Persistence"]);

Console.WriteLine($"[Startup] Environment={builder.Environment.EnvironmentName}; Persistence={persistence}" +
    (persistenceSource is not null ? " (from ROBOT_API_PERSISTENCE)" : " (from appsettings / env config)"));

switch (persistence)
{
    case PersistenceProvider.Ado:
        builder.Services.AddScoped<IMapDataAccess, MapADO>();
        builder.Services.AddScoped<IRobotCommandDataAccess, RobotCommandADO>();
        break;
    case PersistenceProvider.Repository:
        builder.Services.AddScoped<IMapDataAccess, MapRepository>();
        builder.Services.AddScoped<IRobotCommandDataAccess, RobotCommandRepository>();
        break;
    default:
        builder.Services.AddDbContext<RobotContext>(options =>
            options.UseNpgsql(DbConnectionString.Value)
                .LogTo(Console.WriteLine, new[] { DbLoggerCategory.Database.Name })
                .EnableSensitiveDataLogging());
        builder.Services.AddScoped<IMapDataAccess, MapEF>();
        builder.Services.AddScoped<IRobotCommandDataAccess, RobotCommandEF>();
        break;
}

var app = builder.Build();

app.UseHttpsRedirection();

app.MapControllers();

app.Run();
